# LockerScreen
# 在Android手机中，我们经常会见到各种各样的锁屏，你是不是也想要做一个自己的锁屏呢？那么这个项目就是精心为你准备的，通过这个项目你可以了解到如何打造一个属于自己的酷炫锁屏。

# 废话不多说，来两张图吧：

![image](https://github.com/RockySteveJobs/LockerScreen/blob/master/art/img_locker_two.jpg)

项目介绍文章：http://www.jianshu.com/p/67cab477a3d5

## 如果你喜欢，别忘了Star 或者follow 一下哦 ^_^
