import fileinput
def D(a):print(a)
def S(s,I):return int(s.split(" ")[I])
z=-1
def add(M, x):
    if not x in M:
        M[x]=0
    M[x] +=1

def get(M, x):
    return M[x] if x in M else 0

W=[[dict() for i in range(10)] for j in range(10)]
Q=[[dict() for i in range(10)] for j in range(10)]
B=dict()
for l in fileinput.input():
    z+=1
    if z==0:
        N=int(l)
        continue
    l=l[:-1]
    if z<=N:
        add(B, l)
        for i in range(9):
            add(W[i][9], l[:i]+l[i+1:])
            for j in range(i):
                add(W[j][9-i+j], l[:j]+l[i+1:])
                add(Q[j][i], l[:j]+l[j+1:i]+l[i+1:])
        continue
    if z == N+1:
        continue;
    q=l.count("?")
    w=l.count("*")
    if 0 != w:
        p = l.find("*")
        print(get(W[p][len(l)], l.replace("*", "")))
    elif q == 2:
        p = l.find("?")
        P = l.rfind("?")
        print(get(Q[p][P], l.replace("?","")))
    elif q==1:
        p = l.find("?")
        print(get(W[p][9], l.replace("?", "")))
    else:
        print(get(B,l))

