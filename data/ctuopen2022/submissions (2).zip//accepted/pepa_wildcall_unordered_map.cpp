#include <bits/stdc++.h>
using namespace std;

typedef long long int ll;
typedef pair<int, int> pii;
bool R(){return true;}
template<typename T, typename ... Args>
bool R(T & x, Args & ... args){return cin >> x && R(args...);}
void init_io(){ios::sync_with_stdio(false);cin.tie(0);}

#define PB push_back
#define FOR(prom, a, b) for(int prom = (a); prom < (b); prom++)
#define FORDE(prom, a, b) for(int prom = (a); prom >= (b); prom--)
#define ALL(vec) (vec).begin(), (vec).end()
#define MM(co, cim) memset((co), (cim), sizeof((co)))
#define DEB(x) cerr << ">>> " << #x << " : " << x << endl;
#define INF   1000000007
#define INFLL 4000000000000000007LL

int n, q;
string line;
unordered_map<string, int> counts;

void inc_count (const string & x)
{
  if (!counts.count(x)) counts[x] = 0;
  ++counts[x];
}

void solve ()
{
  R(n);
  FOR(qq, 0, n)
  {
    R(line);
    //no missing
    inc_count(line);
    //one missing
    FOR(i, 0, line.length()) inc_count(line.substr(0, i) + "?" + line.substr(i + 1));
    //two missing
    FOR(i, 0, line.length()) FOR(j, i + 1, line.length()) inc_count(line.substr(0, i) + "?" + line.substr(i + 1, j - i - 1) + "?" + line.substr(j + 1));
    //wildcard
    FOR(i, 0, line.length()) FOR(j, i, line.length()) inc_count(line.substr(0, i) + "*" + line.substr(j + 1));
  }
  R(q);
  FOR(qq, 0, q)
  {
    R(line);
    printf("%d\n", counts[line]);
  }
}

int main ()
{
  init_io();
  int T = 1;
  //R(T);
  while (T--) solve();
  return 0;
}
