import sys

numbers = {}


def add_to_map(number):
    if number in numbers:
        numbers[number] += 1
    else:
        numbers[number] = 1


def add_number(number):
    add_to_map(number)
    for i in range(len(number)):
        add_to_map(number[:i] + "?" + number[i + 1 :])
        for j in range(i + 1, len(number)):
            add_to_map(number[:i] + "?" + number[i + 1 : j] + "?" + number[j + 1 :])
    for i in range(len(number)):
        for j in range(i, len(number)):
            add_to_map(number[:i] + "*" + number[j:])

count = int(sys.stdin.readline().rstrip())

for i in range(count):
    add_number(sys.stdin.readline().rstrip())

queries = int(sys.stdin.readline().rstrip())
for i in range(queries):
    query = str(sys.stdin.readline().rstrip())
    if query in numbers:
        print(numbers[query])
    else:
        print(0)
