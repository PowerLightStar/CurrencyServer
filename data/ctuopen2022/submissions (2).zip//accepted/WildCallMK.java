import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;


/**
 * ICPC - CTU Open Contest 2022
 * Sample Solution: Call of the Wild
 * 
 * @author Martin Kacer
 */
public class WildCallMK {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	boolean hasNextToken() {
		try {
			while (!st.hasMoreTokens()) {
				String line = input.readLine();
				if (line == null) return false;
				st = new StringTokenizer(line);
			}
		} catch (IOException ex) { throw new RuntimeException(ex); }
		return true;
	}
	String nextToken() {
		return (!hasNextToken()) ? null : st.nextToken();
	}
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	public static void main(String[] args) {
		new WildCallMK().run();
	}
	
	Map<String,Integer> res = new HashMap<>();

	void addKey(String x) { res.put(x, res.getOrDefault(x, 0) + 1); }
	
	void addNumber(String x) {
		addKey(x);
		for (int i = 0; i < x.length(); ++i) {
			addKey(x.substring(0,i) + '?' + x.substring(i+1));
			for (int j = i+1; j < x.length(); ++j) {
				addKey(x.substring(0,i) + '?' + x.substring(i+1,j) + '?' + x.substring(j+1));
			}
		}
		for (int i = 0; i < x.length(); ++i)
			for (int j = i; j <= x.length(); ++j)
				addKey(x.substring(0,i) + '*' + x.substring(j));
	}
	
	void run() {
		int n = nextInt();
		while (n-->0) addNumber(nextToken());
		int q = nextInt();
		while (q-->0) System.out.println(res.getOrDefault(nextToken(), 0));
	}
}
