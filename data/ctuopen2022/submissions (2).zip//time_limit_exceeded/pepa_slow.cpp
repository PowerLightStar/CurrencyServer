#include <bits/stdc++.h>
using namespace std;

typedef long long int ll;
typedef pair<int, int> pii;
bool R(){return true;}
template<typename T, typename ... Args>
bool R(T & x, Args & ... args){return cin >> x && R(args...);}
void init_io(){ios::sync_with_stdio(false);cin.tie(0);}

#define PB push_back
#define FOR(prom, a, b) for(int prom = (a); prom < (b); prom++)
#define FORDE(prom, a, b) for(int prom = (a); prom >= (b); prom--)
#define ALL(vec) (vec).begin(), (vec).end()
#define MM(co, cim) memset((co), (cim), sizeof((co)))
#define DEB(x) cerr << ">>> " << #x << " : " << x << endl;
#define INF   1000000007
#define INFLL 4000000000000000007LL

int n, q;
vector<string> phones;
string line;

void solve ()
{
  R(n);
  FOR(i, 0, n) 
  {
    R(line);
    phones.PB(line);
  }
  R(q);
  FOR(i, 0, q)
  {
     R(line);
     bool has_c, has_j;
     has_c = has_j = false;
     FOR(i, 0, line.length())
     {
       if (line[i] == '?') has_c = true;
       else if (line[i] == '*') has_j = true;
     }
     int res = 0;
     string pref, suff;
     int kk = 0;
     if (line.find("*") != string::npos)
     {
       while (line[kk] != '*') pref += line[kk++];
       ++kk;
       suff = line.substr(kk);
       reverse(ALL(suff));
     }
     FOR(j, 0, phones.size())
     {
       string rev_phone = phones[j];
       reverse(ALL(rev_phone));
       if (!has_c && !has_j)
       {
         if (phones[j] == line) ++res;
       }
       else if (has_c)
       {
         bool matches = true;
         FOR(k, 0, 9)
         {
           if (line[k] != '?')
           {
             if (line[k] != phones[j][k]) matches = false;
           }
         }
         if (matches) ++res;
       }
       else
       {
         if (pref == phones[j].substr(0, pref.length()))
         {
           if (suff == rev_phone.substr(0, suff.length())) ++res;
         }
       }
     }
     printf("%d\n", res);
  }
}

int main ()
{
  init_io();
  int T = 1;
  //R(T);
  while (T--) solve();
  return 0;
}
