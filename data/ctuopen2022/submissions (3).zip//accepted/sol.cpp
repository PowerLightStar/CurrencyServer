#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'

//#define dbg if(0)cerr

int main(){
  ios::sync_with_stdio(0);cin.tie(0);
  string s;
  cin>>s;
  ll splits=0;
  for (int i = 0; i < s.size()-1; ++ i) {
    if (s[i] == s[i+1]) splits ++;
  }
  cout << (splits+1)/2 << endl;

  return 0;
}
