import fileinput
def D(a):print(a)
def S(s,I):return int(s.split(" ")[I])
for l in fileinput.input():
    l=l[:-1:2]
    S=1
    for i in range(1,len(l)):
        if l[i]!=l[i-1]:
            S+=1
    D(S//2)
