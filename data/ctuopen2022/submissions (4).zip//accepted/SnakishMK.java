import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;


/**
 * ICPC - CTU Open Contest 2022
 * Sample Solution: Snake Game
 * 
 * @author Martin Kacer
 */
public class SnakishMK {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	boolean hasNextToken() {
		try {
			while (!st.hasMoreTokens()) {
				String line = input.readLine();
				if (line == null) return false;
				st = new StringTokenizer(line);
			}
		} catch (IOException ex) { throw new RuntimeException(ex); }
		return true;
	}
	String nextToken() {
		return (!hasNextToken()) ? null : st.nextToken();
	}
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	public static void main(String[] args) {
		new SnakishMK().run();
	}
	
	void run() {
		int w = nextInt(), h = nextInt(), x = nextInt(), y = nextInt();
		System.out.println((w % 2) * (h % 2) == 0 ? "Win" : (x+y) % 2 == 0 ? "Lose" : "Win");
	}
}
