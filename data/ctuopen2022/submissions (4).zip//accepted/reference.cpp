#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main(){
    ll W, H, X, Y; cin >> W >> H >> X >> Y;
    cout << ((W%2==0)||(H%2==0)||((X+Y)%2!=0)?"Win":"Lose") << endl;
    return 0;
}
