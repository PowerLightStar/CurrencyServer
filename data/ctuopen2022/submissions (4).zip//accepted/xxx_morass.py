import fileinput
for l in fileinput.input():
    N, M, X, Y = list(map(int,l[:-1].split(" ")))
    print("Lose" if N*M %2 and X%2 == Y%2 else "Win")
