#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define ZERO (1e-10)
#define INF int(1e9+1)
#define CL(A,I) (memset(A,I,sizeof(A)))
#define DEB printf("DEB!\n");
#define D(X) cout<<"  "<<#X": "<<X<<endl;
#define EQ(A,B) (A+ZERO>B&&A-ZERO<B)
typedef long long ll;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
#define IN(n) int n;scanf("%d",&n);
#define FOR(i, m, n) for (int i(m); i < n; i++)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define FT(m, n) FOR(k, m, n)
#define aa first
#define bb second
void ga(int N,int *A){F(N)scanf("%d",A+i);}
#define MX 222222
int N,S[MX],q,t,T,W,a;
char s[MX];
int main(void){
    scanf("%d%s",&N, s);
    S[0]=88==*s;
    F(N-1)S[i+1]=S[i]+(s[i+1]==88);
    FT(3,N&&(q=k*k)<=N){
        t=4*k-4, T=q-t;
        W+=S[q-1]==t||S[q-1]==T;
        F(N-q)a=S[i+q]-S[i],W+=a==t||a==T;
    }
    printf("%d\n",W);
    return 0;
}
