#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'

//#define dbg if(0)cerr

// Barely O(n^(3/2))
int main(){
  ios::sync_with_stdio(0);cin.tie(0);
  ll n;
  cin>>n;
  string a;
  cin>>a;
  unordered_map<ll,ll> o;

  vector<ll> sizes;
  F(n+1)o[i] = -1;
  vector<vector<ll>> pf(2, vector<ll>(n+1));
  pf[0][0] = a[0] == 'O';
  pf[1][0] = a[0] == 'X';
  for (int i = 1; i < n; ++ i) {
    pf[0][i] = pf[0][i-1] + (a[i] == 'O');
    pf[1][i] = pf[1][i-1] + (a[i] == 'X');
  }

  ll size = 3;
  while (size*size <= n) {
    o[4*size - 4] = (size-2)*(size-2);
    sizes.PB(size*size);
    size ++;
  }
  ll res = 0;
  //dbg << sizes.size() << endl;
  for (int i = 0; i < n; ++ i) {
    for (auto size: sizes) {
      if (size > i+1) break;
      ll c = pf[0][i];
      if (i-size >= 0) c -= pf[0][i-size];
      ll d = pf[1][i];
      if (i-size >= 0) d -= pf[1][i-size];
      //dbg << c << ' ' << d << ' ' << c+d << ' ' << size << endl;
      assert(c+d == size);
      res += ((o[c] == d) || (o[d] == c));
    }
  }
  out(res);
  return 0;
}
