import fileinput
def D(a):print(a)
def S(s,I):return int(s.split(" ")[I])
z=0
W=0
X=[0]*200001
S=[0]*200001
for l in fileinput.input():
    z+=1
    if z==1:continue
    L = len(l) - 1
    for i in range(L):
        if l[i] == "X":
            X[i] = 1
S[0] = X[0]
for i in range(1, L):
    S[i] = S[i-1] + X[i]

for i in range(3 , L):
    if (q := i*i) > L: break;
    t = 4*i -4
    T = q - t
    if S[q-1] == t or S[q-1] == T: W+=1
    i = 0
    while i < L-q:
        a = S[i + q] - S[i]
        if a==T or a==t: W+=1
        i += 1
D(W)
