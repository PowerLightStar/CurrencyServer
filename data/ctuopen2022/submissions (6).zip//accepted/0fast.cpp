#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'

//#define dbg if(0)cerr

int main(){
  ios::sync_with_stdio(0);cin.tie(0);
  ll n;
  cin>>n;
  string a;
  cin>>a;
  vector<pair<ll,ll>> sizes;
  ll size = 3;
  while (size*size <= n) {
    sizes.push_back({4*size - 4, (size-2)*(size-2)});
    size ++;
  }
  ll res = 0;
  for (auto size: sizes) {
    ll c=0, d=0;
    ll total = size.aa + size.bb;
    for (int i = 0; i < total; ++ i) {
      c += a[i] == 'X';
      d += a[i] == 'O';
    }
    for (int i = total; i < n; ++ i) {
      if ((c == size.aa && d == size.bb) || (d == size.aa && c == size.bb)) res++;
      c -= a[i-total] == 'X';
      d -= a[i-total] == 'O';
      c += a[i] == 'X';
      d += a[i] == 'O';
    }
    if ((c == size.aa && d == size.bb) || (d == size.aa && c == size.bb)) res++;
  }
  out(res);
  return 0;
}
