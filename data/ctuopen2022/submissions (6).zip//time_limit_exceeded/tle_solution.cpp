#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'

//#define dbg if(0)cerr

ll o[100007];

// O(n^2)
int main(){
  //vector<ll> o (100007,-1);
  memset(o,-1,sizeof(ll)*100007);
  ios::sync_with_stdio(0);cin.tie(0);
  ll n;
  cin>>n;
  string a;
  cin>>a;
  vector<pair<ll,ll>> sizes;
  ll size = 3;
  F(n)if(a[i] == 'X')a[i]=0;
  F(n)if(a[i] == 'O')a[i]=1;
  while (size*size <= n) {
    o[4*size - 4] = (size-2)*(size-2);
    size ++;
  }

  ll res = 0;
  for (int i = 0; i < n; ++ i) {
    ll c = 0;
    for (int j = i; j < n; ++ j) {
      c += a[j];
      const ll d = (j - i + 1) - c;
      if ((o[c] == d) || (o[d] == c)) res++;
    }
  }
  out(res);
  return 0;
}
