import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;


/**
 * ICPC - CTU Open Contest 2022
 * Sample Solution: Tiger
 * 
 * @author Martin Kacer
 */
public class TigerMK {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	boolean hasNextToken() {
		try {
			while (!st.hasMoreTokens()) {
				String line = input.readLine();
				if (line == null) return false;
				st = new StringTokenizer(line);
			}
		} catch (IOException ex) { throw new RuntimeException(ex); }
		return true;
	}
	String nextToken() {
		return (!hasNextToken()) ? null : st.nextToken();
	}
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	public static void main(String[] args) {
		new TigerMK().run();
	}
	
	List<List<Integer>> graph;
	int[][] tiger, me;
	int[] qn, qp;
	
	void run() {
		int n = nextInt(), m = nextInt(), f = nextInt(), t = nextInt(), s = nextInt();
		graph = new ArrayList<>(n);
		for (int i = 0; i < n; ++i) graph.add(new ArrayList<>());
		for (int i = 0; i < m; ++i) { int a = nextInt(), b = nextInt(); graph.get(a).add(b); graph.get(b).add(a); }
		
		// tiger
		tiger = new int[2][n];
		int qh = 0, qt = 0;
		qn = new int[n*2]; qp = new int[n*2];
		qn[qt] = t; qp[qt++] = 0; tiger[0][t] = 2;
		while (qh < qt) {
			int cn = qn[qh], cp = qp[qh++];
			for (int gn : graph.get(cn)) {
				if (tiger[1-cp][gn] > 0) continue;
				tiger[1-cp][gn] = tiger[cp][cn] + 1;
				qn[qt] = gn; qp[qt++] = 1-cp;
			}
		}
		//for (int p = 0; p < 2; ++p) {
			//System.err.print("   T> ");
			//for (int i = 0; i < n; ++i) System.err.print(tiger[p][i] + " ");
			//System.err.println();
		//}
		
		// myself
		me = new int[2][n];
		qh = qt = 0;
		if (s != t) {
			qn[qt] = s; qp[qt++] = 0; me[0][s] = 2;
		}
		while (qh < qt) {
			int cn = qn[qh], cp = qp[qh++];
			//System.err.println("  -> " + cn + "%" + cp + " = " + me[cp][cn]);
			if (cn == f) {
				System.out.println(me[cp][cn] - 2);
				return;
			}
			for (int gn : graph.get(cn)) {
				if (me[1-cp][gn] > 0) continue;
				if (tiger[1-cp][gn] > 0 && tiger[1-cp][gn] <= me[cp][cn] + 1) continue;  // tiger already could be there
				//System.err.println("  Q: " + gn + "%" + (1-cp) + " = " + (me[cp][cn] + 1));
				me[1-cp][gn] = me[cp][cn] + 1;
				qn[qt] = gn; qp[qt++] = 1-cp;
			}
			if (me[1-cp][cn] == 0 && (tiger[1-cp][cn] == 0 || tiger[1-cp][cn] > me[cp][cn] + 1)) { // do not move
				me[1-cp][cn] = me[cp][cn] + 1;
				qn[qt] = cn; qp[qt++] = 1-cp;
			}
		}
		System.out.println("death");
	}
}
