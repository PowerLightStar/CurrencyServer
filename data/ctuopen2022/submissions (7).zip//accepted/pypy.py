import fileinput
def D(a):print(a)
def S(s,I):return int(s.split(" ")[I])
z=0
for l in fileinput.input():
    z+=1
    if z == 1:
        N=S(l,0)
        M=S(l,1)
        E=S(l,2)
        T=S(l,3)
        B=S(l,4)
        C=[ [-1]*N, [-1]*N ]
        g = [ [] for _ in range(N)]
        continue
    a=S(l,0)
    b=S(l,1)
    g[a].append(b)
    g[b].append(a)

# Tig3r
Q = [0]*(2*N)
b, e = 0, 1
Q[b]=(T, 0)
C[0][T]=0
while b < e:
    x, y = Q[b]
    p = y&1
    b += 1
    for h in g[x]:
        if C[p^1][h] < 0:
            C[p^1][h]=y+1
            Q[e]=(h, y+1)
            e+=1

# Hooman
for i in range(N): g[i].append(i)
b, e = 0, 1
Q[0] = (B, 0)
r = "death"

while b < e:
    x, y = Q[b]
    p = y&1
    b+=1
    if x == E:
        r=y
        break
    for h in g[x]:
        if C[p^1][h] < 0 or C[p^1][h] > y+1:
            C[p^1][h]=0
            Q[e]=(h, y+1)
            e+=1
if B == T:
    r = "death"
print(r)
