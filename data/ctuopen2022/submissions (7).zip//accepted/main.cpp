#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define ZERO (1e-10)
#define INF int(1e9+1)
#define CL(A,I) (memset(A,I,sizeof(A)))
#define DEB printf("DEB!\n");
#define D(X) cout<<"  "<<#X": "<<X<<endl;
#define EQ(A,B) (A+ZERO>B&&A-ZERO<B)
typedef long long ll;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
#define IN(n) int n;scanf("%d",&n);
#define FOR(i, m, n) for (int i(m); i < n; i++)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define FT(m, n) FOR(k, m, n)
#define aa first
#define bb second
void ga(int N,int *A){F(N)scanf("%d",A+i);}
#define MX int(1e5+666)
#define ADD(A,B) (g[A].PB(B),g[B].PB(A))
int a,b, B, E, T, N, M;
vi g[MX];
int C[2][MX];
queue<ii> Q;
void bft(){
    CL(C,-1);
    C[0][T]=0;
    Q.push({T,0});
    while(!Q.empty()){
        int a=Q.front().aa, b=Q.front().bb;
        Q.pop();
        for(auto&h:g[a])if(!~C[!(b&1)][h])
            C[!(b&1)][h]=b+1, Q.push({h, b+1});
    }
}
int bfs(){
    if(B==T)return -1;
    C[0][B]=0;
    Q.push({B,0});
    while(!Q.empty()){
        int a=Q.front().aa, b=Q.front().bb;
        Q.pop();
        if(a==E)return b;
        for(auto&h:g[a])if(!~C[!(b&1)][h]||C[!(b&1)][h]>b+1)
            C[!(b&1)][h]=0, Q.push({h, b+1});
    }
    return -1;
}
int main(void){
    scanf("%d%d%d%d%d", &N, &M, &E, &T, &B);
    F(M)scanf("%d%d",&a,&b),ADD(a,b);
    bft();
    F(N)g[i].PB(i);
    a=bfs();
    if(~a)printf("%d\n", a);
    else puts("death");
    return 0;
}
