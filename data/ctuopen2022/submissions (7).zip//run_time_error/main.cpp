#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define ZERO (1e-10)
#define INF int(1e9+1)
#define CL(A,I) (memset(A,I,sizeof(A)))
#define DEB printf("DEB!\n");
#define D(X) cout<<"  "<<#X": "<<X<<endl;
#define EQ(A,B) (A+ZERO>B&&A-ZERO<B)
typedef long long ll;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
#define IN(n) int n;scanf("%d",&n);
#define FOR(i, m, n) for (int i(m); i < n; i++)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define FT(m, n) FOR(k, m, n)
#define aa first
#define bb second
void ga(int N,int *A){F(N)scanf("%d",A+i);}
#define MX int(1e5)
bitset<MX> C[MX];
vi g[MX];
int a,b, B, E, T, N, M;
queue<ii> Q;
void bft(){
    C[T].set(0);
    Q.push({T,0});
    while(!Q.empty()){
        a=Q.front().aa, b=Q.front().bb;
        Q.pop();
        if(b>2*N||b==MX)break;
        for(auto&h:g[a])if(!C[h][b+1])
            C[h].set(b+1), Q.push({h,b+1});
    }
}
int bfs(){
    while(!Q.empty())Q.pop();
    if(T==B)return -1;
    C[B].set(0);
    Q.push({B,0});
    while(!Q.empty()){
        a=Q.front().aa, b=Q.front().bb;
        Q.pop();
        if(a==E)return b;
        for(auto&h:g[a])if(!C[h][b+1])
            C[h].set(b+1), Q.push({h,b+1});
    }
    return -1;
}
#define ADD(A,B) (g[A].PB(B),g[B].PB(A))
int main(void){
    scanf("%d%d%d%d%d", &N, &M, &E, &T, &B);
    F(M)scanf("%d%d",&a,&b),ADD(a,b);
    bft();
    F(N)ADD(i,i);
    a=bfs();
    if(~a)printf("%d\n", a);
    else puts("death");
    return 0;
}
