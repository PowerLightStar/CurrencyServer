# BEGIN import union_find.py
# DFU
class unionFind:
    """ DFU algorithm for components checking

    parent (list[int]): The component the node is in ("root" is stored here - in the end)
    size (list[int]): Size of component.
    components (int): Number of remaining components.
    """
    parent = None
    size = None
    components = None
    def __init__(self, size:int):
        """ Initialises structure. All node will be in its own component.

        Args:
            size (int): Size of graph.

        Note:
            Graph will be indexed from 0.

        Complexity:
            O(size)
        """
        self.parent = [i for i in range(size)]
        self.size = [1]*size
        self.components = size

    def get_component(self, node: int) -> int:
        """ Finds the component (its root) of input node.

        Args:
            node (int): The node whose component we want to find out.

        Complexity:
            O(log(N))

        Returns:
            int: The component of "node".
        """
        if node != self.parent[node]:
            self.parent[node] = self.get_component(self.parent[node])
        return self.parent[node]

    def connect_nodes(self, node_a: int, node_b: int) -> bool:
        """ Connect nodes "a" and "b" if they are in different component.

         Args:
            node_a (int): One of the nodes to be connected.
            node_b (int): Second node which is to be connected.

        Complexity:
            O(log(N)) -- O(1) amortised.

        Note:
            The smaller component is connected (rooted) to the bigger component.

        Returns:
            bool: True if the nodes were from different component. False otherwise.
        """
        first = self.get_component(node_a)
        second = self.get_component(node_b)
        if first == second:
            return False
        if self.size[first] < self.size[second]:
            first, second = second, first
        self.size[first] += self.size[second]
        self.size[second] = 0
        self.parent[second] = self.parent[first]
        self.components-=1
        return True

    def components_number(self) -> int:
        """ Return number of components of the graph.

        Returns:
            int: Number of components.

        Complexity:
            O(1)
        """
        return self.components

    def component_size(self, node: int) ->int:
        """ Return size of component to which node belongs.

        Args:
            node (int): The node whose component's size we are to get.

        Complexity:
            O(log(N)) -- Amortised O(1)

        Returns:
            The size of component of node.
        """
        return self.size[self.get_component(node)]

    def is_root(self, node: int) -> bool:
        """ Returns true if node is root (i.e. represents) of its component.

        Args:
            node (int): Node for which we check whether it is root.

        Returns:
            bool: True if node is root of component it is in.

        Complexity:
            O(log(N)) -- O(1) amortized.
        """
        return self.get_component(node) == node

# END of import union_find.py
# BEGIN import bridges.py
# Data structure for finding bridges and sudden manipulation(s)
class bridges:
    """ Data structure for searching of bridges in graph and manipulation with such graph.

    Note:
        Nodes in the graph are to be indexed from 0 to size-1.

    Variables:
        graph (list[list[int]]): List of list of neighbors (for each node).
        size (int): Number of nodes in the graph.
        bridges (set[Tuple[int,int]]): Set with pairs - 2 nodes connected by an edge.
            Every bridge will be in set exactly once in "sorted" order.
        bridged_graph (list[list[int]]): List of list of neighbors of "bridged graph" (forest of components without bridges connected by bridges).
        dfu (unionFind): Union Find structure with components of bridged forest.
        subtree_size (list[int]): Size of subtree of bridged-forest.
        tree_size (unionFind): Union Find data structure for trees.
    """
    graph = None
    size = None
    bridges = None
    bridged_graph = None
    dfu = None
    subtree_size = None
    tree_size = None
    def __init__(self, size: int):
        """ Initialises variables of the data structure.

        Args:
            size (int): The number of nodes of the graph.

        Complexity:
            O(size)
        """
        self.size = size
        self.graph = [list() for _ in range(size)]

    @staticmethod
    def __normalize(first: int, second: int):# -> tuple[int, int]:
        """ Returns an edge in normalized state => as tuple where first node has lower index.

        Args:
            first (int): First node connected by an edge.
            second (int): Second node connected by an edge.

        Returns:
            tuple(int,int): Edge with first lower index. (i.e. minmax function in C++)

        Complexity:
            O(1)
        """
        return min(first, second), max(first, second)

    def add_edge(self, first: int, second: int):
        """ Adds bidirectional edge to graph.

        Args:
            first (int): First node of the edge.
            second (int): Second node of the edge.

        Complexity:
            O(N)

        Note:
            Edges shall be indexed from 0 to "size - 1"
        """
        self.graph[first].append(second)
        self.graph[second].append(first)

    def bridges_search(self):
        """ Searches for bridges in graph.

        Complexity:
            O(N) -- times complexity to access hashed set.
        """
        self.bridges = set()
        seen = [False]*self.size
        time_1 = [0]*self.size
        time_2 = [0]*self.size
        time = 0
        # In case the graph is not connected.
        for start in range(self.size):
            if not seen[start]:
                stack = [(start, 0, -1)]
                while len(stack):
                    node, index, parent = stack.pop()
                    if not index:
                        seen[node] = True
                        time_1[node] = time_2[node] = time
                        time += 1
                    else:
                        # After dfs
                        previous_neighbor = self.graph[node][index-1]
                        if previous_neighbor != parent:
                            time_1[node] = min (time_1[node], time_1[previous_neighbor])
                            if time_1[previous_neighbor] > time_2[node]:
                                self.bridges.add(self.__normalize(node, previous_neighbor))
                    if index != len(self.graph[node]):
                        stack.append((node, index + 1, parent))
                        neighbor = self.graph[node][index]
                        if neighbor == parent: continue
                        if seen[neighbor]:
                            time_1[node] = min(time_1[node], time_1[neighbor])
                        else:
                            stack.append((neighbor, 0, node))

    def get_bridges(self):# -> list[tuple]:
        """ Returns list of edges which are bridge. The edges will have first index lower and will be sorted.

            Returns:
                list[tuple[int, int]]: Sorted list of bridges.

            Complexity:
                O(Nlog(N))
        """
        return sorted(list(self.bridges))

    def is_bridge(self, first: int, second: int) -> bool:
        """ Check if given edge is a bridge.

        Args:
            first (int): One of the ends of an edge.
            second (int): Second end of an edge.

        Note:
            The order shall not matter.

        Returns:
            bool: True if the edge is bridge.

        Complexity:
            O(hash-table-access)
        """
        return self.__normalize(first, second) in self.bridges

    def get_bridges_number(self) -> int:
        """ Gets number of found bridges.

        Returns:
            int: The number of bridges in graph.

        Complexity:
            O(1)
        """
        return len(self.bridges)

    def create_bridged_forest(self):
        """ Creates bridged forest.

        Requires:
            bridges_search (tho it will call the function if it was not called yet before).
            unionFind: Import of unionFind data structure.

        Complexity:
            O(Nlog(N))
        """
        # Proceeds bridges search if it was not done before.
        if self.bridges is None: self.bridges_search()
        self.dfu = unionFind(self.size)
        # Create components for bridged forest
        # Complexity: O(NlogN)
        for node in range(self.size):
            for neighbor in self.graph[node]:
                if not self.is_bridge(node, neighbor):
                    self.dfu.connect_nodes(node, neighbor)
        # Connect nodes by bridges / create forest graph
        # Note: From now on, only dfu components will be considered as nodes
        # Complexity: O(len(self.bridges)
        self.bridged_graph = [list() for _ in range(self.size)]
        for first, second in self.bridges:
            comp_one = self.dfu.get_component(first)
            comp_two = self.dfu.get_component(second)
            self.bridged_graph[comp_one].append(comp_two)
            self.bridged_graph[comp_two].append(comp_one)
        # Creates "order" - list with walk through tree (some kind of dfs).
        # Complexity: O(size)
        order = []
        parents = [-1] * self.size
        seen  = [0] * self.size
        stack = []
        for start in range(self.size):
            if not seen[start] and self.dfu.is_root(start):
                stack.append((start, True, -1))
                while len(stack):
                    node, operation, parent = stack.pop()
                    parents[node] = parent
                    if operation:
                        stack.append((node, False, parent))
                        for neigbor in self.bridged_graph[node]:
                            if neigbor != parent:
                                stack.append((neigbor, True, node))
                    else:
                        order.append(node)
                        seen[node] = True
        # Find sizes of bridged subtrees.
        # Complexity: O(Nlog(N))
        self.subtree_size = [0]*self.size
        for node in order:
            self.subtree_size[node] = self.dfu.component_size(node)
            for neigbor in self.bridged_graph[node]:
                if neigbor != parents[node]:
                    self.subtree_size[node] += self.subtree_size[neigbor]
        # Find size of each subtree
        # Complexity: O(Nlog(N))
        self.tree_size = unionFind(self.size)
        for node in range(self.size):
            for neigbor in self.graph[node]:
                self.tree_size.connect_nodes(node, neigbor)

    def get_bridge_sizes(self, first: int, second: int) -> int:
        """ Finds sizes of each component which would be created by splitting given bridge.

        Args:
            first (int): One of the nodes of the bridge.
            second (int): The second node of the bridge.

        Returns:
            tuple(int, int): Sizes of component created by splitting by the bridge.

        Note:
            None is returned if edge is not bridge (or edge...)

        Complexity:
            O(log(N)) -- O(1) amortized.
        """
        if not self.is_bridge(first, second): return None
        component_first = self.dfu.get_component(first)
        component_second = self.dfu.get_component(second)
        if self.subtree_size[component_first] < self.subtree_size[component_second]:
            return self.subtree_size[component_first], self.tree_size.component_size(second) - self.subtree_size[component_first]
        return self.tree_size.component_size(first) - self.subtree_size[component_second], self.subtree_size[component_second]

# END of import bridges.py
#from __future__ import annotations
import sys
sys.setrecursionlimit(1000000)
def D(a):print(a)
def line():return sys.stdin.readline().strip()
def next_int():return int(line())
def line_ints():return list(map(int,line().split(" ")))
N, M = line_ints()
s = [line() for _ in range(N)]
Z = dict()
z = []
for i in range(N):
    for j in range(M):
        if s[i][j] == "#":
            Z[(i, j)] = len(z)
            z.append([i, j])
T=len(z)
G = bridges(T)
for i in range(N):
    for j in range(M):
        if s[i][j] == "#":
            if i+1 != N and s[i+1][j] == "#":
                G.add_edge(Z[(i, j)], Z[(i+1, j)])
            if j+1 != M and s[i][j+1] == "#":
                G.add_edge(Z[(i, j)], Z[(i, j+1)])
G.create_bridged_forest()
B = G.get_bridges()
g = G.graph
def ok(O):
    global z
    H = [z[i] for i in O]
    o = []
    for i in range (4):
        H = [[-j, i] for i, j in H]
        x = min([i for i, _ in H])
        y = min([i for _, i in H])
#        P = [(i-x, j-y) for i, j in H]
        P = [(i-x)*512 + j-y for i, j in H]
        P.sort()
#        o.append(tuple(P))
        o.append(tuple(P).__hash__()) #Slightly less correct but I trust it :P
    o.sort()
    return tuple(o)
f = [ G.get_bridge_sizes(i,j)[0] for i, j in B]
for m in range(1, T):
    if 0 == T%m:
        if sum([i % m == 0 for i in f]) +1 != T//m:continue
        d = unionFind(T)
        x = True
        for u in range(T):
            for h in g[u]:
                if not G.is_bridge(u, h) or G.get_bridge_sizes(u, h)[0] % m:
                    d.connect_nodes(u, h)
                    x &= d.component_size(u) <= m
        x&= d.components_number() == T//m
        if not x: continue
        C = [list() for _ in range(T)]
        for u in range(T):
            C[d.get_component(u)].append(u)
        W = set()
        for u in range(T):
            if x and d.is_root(u):
                x &= d.component_size(u) == m
                W.add(ok(C[u]))
                x &= len(W) == 1
        if x and len(W) == 1:
            D(T//m)
            sys.exit(0)
D(1)
