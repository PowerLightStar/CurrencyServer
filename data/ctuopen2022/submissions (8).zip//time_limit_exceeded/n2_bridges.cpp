#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'

//#define dbg if(0)cerr
#define MX 300
#define INF (1ll << 50)

bool vis[MX][MX];
ll low[MX][MX];
ll tin[MX][MX];
ll t;
ll mtx[MX][MX];
ll n,m;
ll target_size;
ll sz[MX][MX];
bool ok;
pair<ll,ll> timeToTile[MX*MX];
ll tilesCnt=0;

vvll pattern;
bool pattern_set;

vvll tiles_to_pattern(vector<pair<ll,ll>> tiles) {
  ll minx=INF, miny=INF;
  ll maxx=-1,maxy=-1;
  for (auto i: tiles) {
    minx = min(minx, i.aa);
    miny = min(miny, i.bb);
    maxx = max(maxx, i.aa);
    maxy = max(maxy, i.bb);
  }
  for (auto & i: tiles) {
    i.aa -= minx;
    i.bb -= miny;
  }
  vvll pat = vvll(maxx - minx + 1, vll(maxy - miny + 1, 0)); 
  for (auto & i: tiles) {
    pat[i.aa][i.bb] = 1;
  }
  return pat;
}

vvll rot90(const vvll & a) {
  vvll b = vvll(a[0].size(), vll(a.size()));
  F(a.size())FF(a[i].size())b[j][a.size() - 1 - i] = a[i][j];
  return b;
}

void print_pat(const vvll & a) {
  /*F(a.size()) {
    FF(a[i].size()) {
      if (a[i][j]) dbg << '#';
      else dbg << ".";
    }
    dbg << endl;
  }*/
  //dbg << a.size() << " " << a[0].size() << endl;
}

bool good_pattern(vector<pair<ll,ll>> tiles) {
  if (!pattern_set) {
    pattern_set=1;
    pattern = tiles_to_pattern(tiles);
    return 1;
  }
  auto pat = tiles_to_pattern(tiles);
  //dbg << "Should be:" << endl;
  print_pat(pattern);
  F(4) {
    //dbg << "Testing now:" << endl;
    print_pat(pat);
    if (pat == pattern) return 1;
    pat = rot90(pat);
  }
  return 0;
}

vector<pair<ll,ll>> tilesStack;

bool found_goal;
ll goal_x, goal_y;
pair<pair<ll,ll>,pair<ll,ll>> fb;
ll steps=0;
ll dfs2(ll x, ll y) {
  ll res=1;
  if (vis[x][y]) return 0;
  vis[x][y]=1;
  if (x == goal_x and y == goal_y) {
    found_goal=1;
    return 0;
  }
  if (found_goal) return 0;

  for (int di = -1; di <= 1; ++ di) {
    for (int dj = -1; dj <= 1; ++ dj) {
      if (di*di + dj*dj == 1) {
        if (di+x < 0 || di+x >= n || dj+y < 0 || dj+y >= m) continue;
        if (!mtx[di+x][dj+y]) continue;
        if (x == fb.aa.aa && y == fb.aa.bb && di+x == fb.bb.aa && dj+y == fb.bb.bb) continue;
        swap(fb.aa, fb.bb);
        if (x == fb.aa.aa && y == fb.aa.bb && di+x == fb.bb.aa && dj+y == fb.bb.bb) continue;
        res += dfs2(di+x,dj+y);
      }
    }
  }
  steps++;
  return res;
}

bool is_solid(ll x, ll y) {
  return x >= 0 and x < n and y >= 0 and y < m and mtx[x][y];
}

ll bfs(ll x, ll y) {
  queue<pair<ll,ll>> q;
  q.push({x,y});
  vis[x][y]=1;
  ll res=1;
  while (q.size()) {
    pair<ll,ll> cur = q.front();
    q.pop();
    x = cur.aa;
    y = cur.bb;
    for (int di = -1; di <= 1; ++ di) {
      for (int dj = -1; dj <= 1; ++ dj) {
        if (di*di + dj*dj == 1) {
          if (di+x < 0 || di+x >= n || dj+y < 0 || dj+y >= m) continue;
          if (!mtx[di+x][dj+y]) continue;
          if (x == fb.aa.aa && y == fb.aa.bb && di+x == fb.bb.aa && dj+y == fb.bb.bb) continue;
          swap(fb.aa, fb.bb);
          if (x == fb.aa.aa && y == fb.aa.bb && di+x == fb.bb.aa && dj+y == fb.bb.bb) continue;
          if (!vis[di+x][dj+y]) {
            q.push({di+x,dj+y});
            vis[di+x][dj+y]=1;
            res++;
            if (di+x == goal_x and dj+y == goal_y) {
              found_goal = 1;
              return 0;
            }
          }
        }
      }
    }
  }
  return res;
}

bool is_bridge(ll x1, ll y1, ll x2, ll y2) {
  // first check if it's like a block
  if (x1 == x2) {
    if (is_solid(x1+1, y1) and is_solid(x1+1, y2)) return false;
    if (is_solid(x1-1, y1) and is_solid(x1-1, y2)) return false;
  }
  if (y1 == y2) {
    if (is_solid(x1, y1+1) and is_solid(x1, y2+1)) return false;
    if (is_solid(x1, y1-1) and is_solid(x1, y2-1)) return false;
  }

  memset(vis, 0, sizeof(bool) * MX * MX);
  found_goal = 0;
  fb = {{x1, y1}, {x2, y2}};
  goal_x = x2;
  goal_y = y2;
  steps=0;
  //ll found = dfs2(x1,y1);
  ll found = bfs(x1,y1);
  return found != tilesCnt;
}

ll bridges_cnt = 0;
vector<pair<pair<ll,ll>,pair<ll,ll>>> get_all_bridges() {
  vector<pair<pair<ll,ll>,pair<ll,ll>>> res;
  for (int x = 0; x < n; ++ x) {
    dbg << x << endl;
    for (int y = 0; y < m; ++ y) {
      if (!mtx[x][y]) continue;
      for (int di = 0; di <= 1; ++ di) {
        for (int dj = 0; dj <= 1; ++ dj) {
          if (di*di + dj*dj == 1) {
            if (di+x < 0 || di+x >= n || dj+y < 0 || dj+y >= m) continue;
            if (!mtx[di+x][dj+y]) continue;
            if (is_bridge(x, y, di+x, dj+y)) {
              bridges_cnt++;
            }
          }
        }
      }
    }
  }
  return res;
}

void dfs(ll x, ll y, ll px, ll py) {
  t ++;
  tin[x][y] = t;
  low[x][y] = min(low[x][y], t);
  vis[x][y]=1;
  ll size=1;
  for (int di = -1; di <= 1; ++ di) {
    for (int dj = -1; dj <= 1; ++ dj) {
      if (di*di + dj*dj == 1) {
        if (di+x < 0 || di+x >= n || dj+y < 0 || dj+y >= m) continue;
        if (!mtx[di+x][dj+y]) continue;
        if (di+x == px && dj+y == py) continue;
        if (vis[di+x][dj+y]) low[x][y] = min(low[x][y], tin[di+x][dj+y]);
        else {
          dfs(di+x,dj+y,x,y);
          size += sz[di+x][dj+y];
          low[x][y] = min(low[x][y], low[di+x][dj+y]);
        }

        if (mtx[di+x][dj+y] && low[di+x][dj+y] > tin[x][y]) {
          //cout << "bridge: " << x << "," << y << " -> " << di+x << " " << dj+y << endl;
          if (sz[di+x][dj+y] == target_size) {
            // cut this bridge
            size -= target_size;
            // collect the tiles in the component
            vector<pair<ll,ll>> tiles;
            while (tilesStack.size()) {
              ll tx = tilesStack.back().aa;
              ll ty = tilesStack.back().bb;
              if (tin[tx][ty] >= tin[di+x][dj+y]) {
                tiles.PB(tilesStack.back());
                tilesStack.pop_back();
              } else {
                break;
              }
            }
            assert(tiles.size() == target_size);
            ok &= good_pattern(tiles);
            // check that it's the same pattern
          } else if (sz[di+x][dj+y] > target_size) {
            ok=0;
          }
        }
      }
    }
  }
  tilesStack.PB({x,y});
  sz[x][y] = size;
}

bool test(ll size) {
  F(MX)FF(MX) low[i][j]=INF;
  F(MX)FF(MX) vis[i][j]=0;
  F(MX)FF(MX) tin[i][j]=0;
  t=0;
  target_size=size;
  ok=1;
  pattern_set=0;
  tilesStack.clear();
  F(n)FF(m){
    if (mtx[i][j]) {
      dfs(i,j,-1,-1);
      // check the last component
      ok &= tilesStack.size() == size;
      ok &= good_pattern(tilesStack);
      return ok;
    }
  }
  return 0;
}

using namespace std;
int main(){
  cin>>n>>m;
  ll cnt=0;
  F(n){
    string a;
    cin>>a;
    FF(m) cnt += (mtx[i][j] = (a[j] == '#'));
  }
  auto bridges = get_all_bridges();
  dbg << "bridges: " << bridges_cnt << endl;
  tilesCnt = cnt;
  dbg << cnt << " " << cnt << endl;
  ll res=1;
  for (ll i = 1; i*i <= cnt; ++ i) {
    if (cnt%i == 0) {
      if (test(i)) res = max(res, cnt/i);
      if (test(cnt/i)) res = max(res, i);
    }
  }
  out(res);
  return 0;
}
