#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define ZERO (1e-10)
#define INF int(1e9+1)
#define CL(A,I) (memset(A,I,sizeof(A)))
#define DEB printf("DEB!\n");
#define D(X) cout<<"  "<<#X": "<<X<<endl;
#define EQ(A,B) (A+ZERO>B&&A-ZERO<B)
typedef long long ll;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
#define IN(n) int n;scanf("%d",&n);
#define FOR(i, m, n) for (int i(m); i < n; i++)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define FT(m, n) FOR(k, m, n)
#define aa first
#define bb second
void ga(int N,int *A){F(N)scanf("%d",A+i);}
#define MX 2000
unordered_map<int,int> F;
int A[MX][MX],a;
int main(void){
    F[1]=1;
    F(MX)if(i>1){
        FF(i){
            if(!j||j==i-1)A[i][j]=1;
            else {
                a=A[i][j]=min(A[i-1][j]+A[i-1][j-1], INF);
                if(!F.count(a))F[a]=i;
            }
        }
    }
    FT(MX,INF){
        ll a=k*(k-1ll)/2;
        if(a>INF)break;
        if(!F.count(a))F[a]=k+1;
    }
    IN(_)F(_)scanf("%d",&a),printf("%d\n",F.count(a)?F[a]:a+1);
    return 0;
}
