import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * ICPC - CTU Open Contest 2022
 * Sample Solution: Pascal's Triangle
 * 
 * @author Martin Kacer
 */
public class PascalMK {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	boolean hasNextToken() {
		try {
			while (!st.hasMoreTokens()) {
				String line = input.readLine();
				if (line == null) return false;
				st = new StringTokenizer(line);
			}
		} catch (IOException ex) { throw new RuntimeException(ex); }
		return true;
	}
	String nextToken() {
		return (!hasNextToken()) ? null : st.nextToken();
	}
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	public static void main(String[] args) {
		new PascalMK().run();
	}
	
	static int MAX = 1_000_000_000, INF = MAX+11, SMALL = 2000;  // (SMALL choose 3) > MAX
	Map<Integer,Integer> lookup = new HashMap<>();
	int[][] triangle = new int[SMALL][SMALL];
	
	int solveOne(int c) {
		Integer r = lookup.get(c);
		return (r != null) ? r : c;
	}
	
	void run() {
		for (int n = 0; n < SMALL; ++n) triangle[n][0] = triangle[n][n] = 1;
		for (int n = 1; n < SMALL; ++n) for (int k = 1; k < n; ++k) {
			if ((triangle[n][k] = triangle[n-1][k-1] + triangle[n-1][k]) > INF)
				triangle[n][k] = INF;
		}
		for (int n = SMALL;;++n) {
			int c = n*(n-1)/2;
			if (c > MAX) break;
			lookup.put(c, n);
		}
		for (int n = SMALL; --n >= 0; ) for (int k = 0; k <=n; ++k) lookup.put(triangle[n][k], n);
		int q = nextInt();
		while (q-->0) {
			System.out.println(solveOne(nextInt()) + 1);
		}
	}
}
