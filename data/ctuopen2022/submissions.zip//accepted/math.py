import fileinput
def D(a):print(a)
def S(s,I):return int(s.split(" ")[I])
MX=100000
MOD=29996224275833
F=[1]*MX
I=[1]*MX
J=[1]*MX
def pre():
    global F, I, J, MOD, MX
    for k in range(2,MX):
        F[k]=(F[k-1]*k)%MOD
        J[k]=-(((MOD)//k)*J[MOD%k])%MOD+MOD
        I[k]=(I[k-1]*J[k])%MOD

def C(N, K):
    global F, I, J, MOD, MX
    return 0 if N < K else (F[N]*I[K]%MOD)*I[N-K]%MOD

def main():
    T = 1000000000
    pre()
    O = { 1 : 1 }
    for i in range(2222):
        for j in range(i, MX):
            a = C(j, i)
            if a > T:
                break
            if ( not a in O) or (O[a] > j):
                O[a] = j

    z=0
    for l in fileinput.input():
        z+=1
        if z == 1: continue
        a = int(l)
        if a in O: D(O[a] + 1)
        else: D(a + 1)

main()
