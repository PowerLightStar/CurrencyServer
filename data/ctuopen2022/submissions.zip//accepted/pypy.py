import fileinput
def D(a):print(a)
def S(s,I):return int(s.split(" ")[I])
def main():
    O = { 1 : 1 }
    X = 2000
    P = [ [1] * X for _ in range(X) ]
    for i in range(1, X):
        for j in range(1, i-1):
            P[i][j] = P[i-1][j] + P[i-1][j-1]
            if not P[i][j] in O:
                O[P[i][j]] = i;

    for i in range(1, 100000):
        a = i * (i-1) / 2
        if not a in O:
            O[a] = i + 1
    z=0
    for l in fileinput.input():
        z+=1
        if z == 1: continue
        a = int(l)
        if a in O: D(O[a])
        else: D(a + 1)

main()
