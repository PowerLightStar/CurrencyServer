import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;


/**
 * ICPC - CTU Open Contest 2022
 * Invalid Solution: Pascal's Triangle
 * This only looks up first 1000 rows.
 * 
 * @author Martin Kacer
 */
public class PascalWrongSmallOnlyMK {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	boolean hasNextToken() {
		try {
			while (!st.hasMoreTokens()) {
				String line = input.readLine();
				if (line == null) return false;
				st = new StringTokenizer(line);
			}
		} catch (IOException ex) { throw new RuntimeException(ex); }
		return true;
	}
	String nextToken() {
		return (!hasNextToken()) ? null : st.nextToken();
	}
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	public static void main(String[] args) {
		new PascalWrongSmallOnlyMK().run();
	}
	
	static int MAX = 1_000_000_000, SMALL = 1000, INF = MAX+11;
	Map<Integer,Integer> lookup = new HashMap<>();
	int[][] triangle = new int[SMALL][SMALL];
	
	void run() {
		for (int n = 0; n < SMALL; ++n) triangle[n][0] = triangle[n][n] = 1;
		for (int n = 1; n < SMALL; ++n) for (int k = 1; k < n; ++k) {
			if ((triangle[n][k] = triangle[n-1][k-1] + triangle[n-1][k]) > INF)
				triangle[n][k] = INF;
		}
		for (int n = SMALL; --n >= 0; ) for (int k = 0; k <=n; ++k) lookup.put(triangle[n][k], n);
		int q = nextInt();
		while (q-->0) {
			int c = nextInt();
			Integer r = lookup.get(c);
			if (r != null) { System.out.println(r+1); continue; }
		}
	}
}
