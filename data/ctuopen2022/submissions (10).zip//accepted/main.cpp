#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define ZERO (1e-10)
#define INF int(1e9+1)
#define CL(A,I) (memset(A,I,sizeof(A)))
#define DEB printf("DEB!\n");
#define D(X) cout<<"  "<<#X": "<<X<<endl;
#define EQ(A,B) (A+ZERO>B&&A-ZERO<B)
typedef long long ll;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
#define IN(n) int n;scanf("%d",&n);
#define FOR(i, m, n) for (int i(m); i < n; i++)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define FT(m, n) FOR(k, m, n)
#define aa first
#define bb second
void ga(int N,int *A){F(N)scanf("%d",A+i);}
#define MX 333333
//#define DD(X,Y,x,y) sqrt(pow(abs(X-x),2)+pow(abs(y-Y), 2))
#define PW(X) ll(X)
#define DD(X,Y,x,y) (PW(abs(X-x))+PW(abs(y-Y)))
int N,a ,b, L[MX], U[MX], I=-1, W[MX], C[MX][2];
ll dp[MX][2], S;
ll dyn(int u, int l){
    if(u==I+1)return 0;
    ll&v=dp[u][l];
    if(C[u][l]++)return v;
    v=1e18;
    if(!u)return v=min(dyn(u+1, 0), dyn(u+1, 1));
    int y=l?L[u-1]:U[u-1];
    return v=min(DD(W[u-1], y, W[u], L[u])+dyn(u+1, 0),
                 DD(W[u-1], y, W[u], U[u])+dyn(u+1, 1));
}
int main(void){
    scanf("%d",&N);
    vii X;
    F(N){
        scanf("%d%d",&a,&b);
        X.PB({a,b});
    }
    sort(X.begin(), X.end());
    F(N){
        if(!i||X[i].aa!=X[i-1].aa)
            W[++I]=X[i].aa, L[I]=U[I]=X[i].bb;
        else S+=DD(0,U[I],0,X[i].bb),U[I]=X[i].bb;
    }
    printf("%lld\n", dyn(0,0) + S);
    return 0;
}
