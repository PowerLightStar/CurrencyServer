#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'
#define INF (1ll << 40)

//#define dbg if(0)cerr
ll dist(ll x, ll y, ll x2, ll y2) {
  return abs(x - x2) + abs(y - y2);
}

int main(){
  ios::sync_with_stdio(0);cin.tie(0);
  ll n;
  cin>>n;
  // x -> min cost, max cost
  map<ll,pair<ll,ll>> pt;
  vector<ll> xs;
  ll res = 0;
  F(n){
    ll x,y;
    cin>>x>>y;
    if (pt.find(x) == pt.end()) {
      pt[x].aa = INF;
      pt[x].bb = -INF;
      xs.PB(x);
    }
    pt[x].aa = min(pt[x].aa, y);
    pt[x].bb = max(pt[x].bb, y);
  }
  sort(xs.begin(),xs.end());
  ll cnt = 0;
  vector<pair<ll,ll>> dp(xs.size());
  dp[0].aa = dp[0].bb = 0;
  for (int i = 0; i < xs.size(); ++ i) {
    ll x = xs[i];
    res += pt[x].bb - pt[x].aa;
    if (!i) continue;
    res += x - xs[i-1];
    dp[i].aa = INF;
    dp[i].bb = INF;

    dp[i].aa = min(dp[i].aa, dp[i-1].aa + abs(pt[xs[i-1]].aa - pt[x].bb));
    dp[i].aa = min(dp[i].aa, dp[i-1].bb + abs(pt[xs[i-1]].bb - pt[x].bb));

    dp[i].bb = min(dp[i].bb, dp[i-1].aa + abs(pt[xs[i-1]].aa - pt[x].aa));
    dp[i].bb = min(dp[i].bb, dp[i-1].bb + abs(pt[xs[i-1]].bb - pt[x].aa));
  }
  ll dpopt = min(dp[xs.size()-1].aa, dp[xs.size()-1].bb);
  out(res + dpopt);
  return 0;
}
