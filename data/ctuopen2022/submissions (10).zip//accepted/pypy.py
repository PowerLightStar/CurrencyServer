from __future__ import annotations
# BEGIN import dijkstra.py
# Shortest Path: Dijkstra
from heapq import heappush, heappop
class dijkstra:
    """ Dijkstra's shortest path algorithm.

            - Create graph
            - Start algorithm from a start node.
            - Query path length

        Variables:
            graph (list[tuple]): Edges to neighbors (with values).
            parent (list[int]): The parent of each edge during algorithm.
            seen (list[int]): Length from "start" to "node"
            size (int): Number of nodes in graph
    """
    graph = None
    parent = None
    seen = None
    size = None
    def __init__(self, size: int):
        """ Initialisation of class -- creates empty lists of edges.

        Complexity:
            O(size)

        Args:
            size (int): Size of list
        """
        self.size = size
        self.graph = [list() for _ in range(size)]

    def add_uni(self, begin: int, end: int, price: int):
        """ Adds uni-directional edge to the graph

        Args:
            begin (int): Start of the edge.
            end (int): End of the edge.
            price (int): Price of the travel through the edge.

        Complexity:
            O(1)
        """
        self.graph[begin].append((end, price))

    def add_bi(self, first: int, second: int, price: int):
        """ Adds bi-directional edge to the graph

        Args:
            first (int): Start/end of the edge.
            second (int): End/start of the edge.
            price (int): Price of the travel through the edge.

        Complexity:
            O(1)
        """
        self.add_uni(first, second, price)
        self.add_uni(second, first, price)

    def search(self, start: int, operation = lambda a, b: a + b):
        """ Process the graph from start. Find the shortest distance to each possible node.

        Args:
            start (int): The node from which we spread
            operation (function)

        Complexity:
            O(Nlog(M))
        """
        self.parent = [-1]*self.size
        self.seen = [None]*self.size
        p_queue = []
        S = 1
        heappush(p_queue, (0, start))
        self.seen[start] = 0
        while S:
            price, node = heappop(p_queue)
            S-=1
            if self.seen[node] != price: continue
            for neighbor, value in self.graph[node]:
                if self.seen[neighbor] is None or self.seen[neighbor] > operation(price, value):
                    self.parent[neighbor] = node
                    self.seen[neighbor] = operation(price, value)
                    S+=1
                    heappush(p_queue, (operation(price, value), neighbor))

    def path_length(self, destination: int, bad = None) -> int:
        """ Obtains the length of path from "start" to "destination"

        Args:
            destination (int): The final node to which the length is to be obtained.

        Complexity:
            O(1)

        Returns:
            int: Length of path from "start" to "destination".
                None is returned if there is no path.
        """
        if self.seen[destination] is None: return bad
        return self.seen[destination]

# END of import dijkstra.py
# BEGIN import point.py
# 3 Dimensional point with basic operations
import math
class Point:
    """ Class which represents point in 3 dimensions (or 2 if last parameter is not set)

    Variables:
        x (float): X coordinate
        y (float): Y coordinate
        z (float): Z coordinate
    """
    x = None
    y = None
    z = None
    def __init__(self, x: float, y: float, z: float = 0):

        """ Initialisation of point by 2 or 3 of its coordinates

        Args:
            x (float): X coordinate of point.
            y (float): Y coordinate of point.
            z (float): Z coordinate of point (defaults to 0).

        Complexity:
            O(1)
        """
        self.x, self.y, self.z = x, y, z

    def __sub__(self, point: Point) -> Point:
        """ Subtraction operator for two point.

        Args:
            point (Point) Another point which is to be subtracted.

        Note:
            This function does not mangle with class - it creates new one.

        Complexity:
            O(1)

        Returns:
            Point: Result of operation "this point" - "arg point".

        Note:
            This is a scalar operation.
        """
        return Point(self.x-point.x, self.y-point.y, self.z-point.z)

    def __lt__(self, point: Point) -> bool:
        """ Operator "<" between two points. The lower coordinates the lower - priority X -> y -> z.

        Args:
            point (Point): The point with which we want to compare.

        Returns:
            bool: True, if this point is lesser than argument.

        Complexity:
            O(1)
        """
        if self.x != point.x: return self.x < point.x
        if self.y != point.y: return self.y < point.y
        return self.z < point.z

    def __repr__(self) -> str:
        """ Returns better representation of object for debugging.

        Returns:
            str: Representation if form of (x, y, z)

        Complexity:
            O(1)
        """
        return f"({self.x}, {self.y}, {self.z})"

    def dot(self, point: Point) -> float:
        """ Dot product of two points

        Args:
            point (Point): The point to get dot product with

        Complexity:
            O(1)

        Returns:
            float: The dot product of two points.

        Note:
            This is a scalar operation.
        """
        return self.x*point.x + self.y*point.y + self.z*point.z

    def cross(self, point: Point) -> Point:
        """ Cross product of two points

        Args:
            point (Point): The point to get cross product with

        Complexity:
            O(1)

        Returns:
            Point: The cross product of "this point" and "argument point".

        Note:
            This is a vector operation
        """
        return Point(self.y*point.z - self.z*point.y,
                     self.z*point.x - self.x*point.z,
                     self.x*point.y - self.y*point.x)

    def absolute(self) -> float:
        """ Returns the absolute of Point (|point|).

        Returns:
            float: |point|

        Complexity:
            O(1)
        """
        return pow((self.x ** 2 + self.y ** 2 + self.z ** 2), 0.5)

    def distance(self, point: Point) -> float:
        """ Find distance between two points.

        Args:
            point (Point): The second point to which we are seeking the distance.

        Returns:
            float: Distance between points.

        Complexity:
            O(1)
        """
        return abs(self.x-point.x)+abs(self.y-point.y)+abs(self.z-point.z)



# END of import point.py
import sys
sys.setrecursionlimit(1000000)
def D(a):print(a)
def line():return sys.stdin.readline().strip()
def next_int():return int(line())
def line_ints():return list(map(int,line().split(" ")))
N = next_int()
P = []
for i in range(N):
    a, b = line_ints()
    P.append(Point(a, b))
P.sort()
Z = []
for p in P:
    if not Z or p.x != Z[-1][-1].x:
        Z.append([p])
    else:
        Z[-1].append(p)
I = len(Z)
G = dijkstra(I*4+1)
G.add_uni(4*I, 0, 0)
G.add_uni(4*I, I, 0)
def dst(A):
    S = 0
    for i in range(len(A)-1):
        S+=A[i].distance(A[i+1])
    return S
for i in range(I):
    b = Z[i][0]
    e = Z[i][-1]
    G.add_uni(i,   3*I+i, dst(Z[i]))
    G.add_uni(I+i, 2*I+i, dst(Z[i]))
    if i+1 != I:
        B = Z[i+1][0]
        E = Z[i+1][-1]
        G.add_uni(2*I+i, i+1,   b.distance(B))
        G.add_uni(2*I+i, I+i+1, b.distance(E))
        G.add_uni(3*I+i, i+1,   e.distance(B))
        G.add_uni(3*I+i, I+i+1, e.distance(E))
G.search(4*I)
D(f"{min(G.path_length(3*I+I-1), G.path_length(2*I+I-1))}")


