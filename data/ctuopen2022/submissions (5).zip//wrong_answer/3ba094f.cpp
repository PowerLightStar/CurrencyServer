#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef double ld;

#define EPS (1e-10)

// double comparasion
//basics
int dcmp(ld x){ return (fabs(x)<EPS) ? 0 : (x<0 ? -1 : 1); }
bool eq(ld a, ld b) { return fabs(a-b) <= fabs(a+b) * EPS || fabs(a-b) < EPS; }
//const ld M_PI = acos(-1.) // M_PI is usually defined
///basics

// POINTS ///////////////////////////////////////////////////////////// 

//point
// represents both Point and Vector
struct Pt{
    ld x, y;
    bool operator <(const Pt &p) const { return x < p.x || (x == p.x && y < p.y); }
    // or return x < p.x-EPS || eq(x, p.x) && y < p.y-EPS);
    Pt operator+(const Pt &p){ return{x+p.x, y+p.y}; }
    Pt operator-(const Pt &p){ return{x-p.x, y-p.y}; }
    Pt operator-(){ return{-x, -y}; }
    Pt operator*(ld d){ return {x*d, y*d}; }
    Pt operator/(ld d){ return {x/d, y/d}; }
    friend ostream &operator<<(ostream &os, const Pt &a){ os<<a.x<<' '<<a.y; return os; }
    friend istream &operator>>(istream &is, Pt &a){ is>>a.x>>a.y; return is; }
};
bool operator==(const Pt &a, const Pt &b){ return eq(a.x,b.x) && eq(a.y,b.y); }  
bool operator!=(const Pt &a, const Pt &b){ return !(a==b); }
namespace std {
    template <> struct hash<Pt> {
        size_t operator()(const Pt &a) const { return (hash<ld>()(a.x) ^ hash<ld>()(a.y)); }
    };
}
///point
typedef vector<Pt> Polygon;

//point_vector
// has + sign for left side and - for right side
// equals |a|*|b|*cos(alf)
ld vec(Pt a, Pt b){ return a.x*b.y-a.y*b.x; }
ld vec(Pt a, Pt b, Pt c){ return vec(b-a, c-a); }
// similar vector -> + / oposite -> - sign
ld dot(Pt a, Pt b){ return a.x*b.x+a.y*b.y; }
ld norm(Pt a){ return hypot(a.x, a.y); }
ld angle(Pt a, Pt b){ return acos(dot(a, b)/norm(a)/norm(b)); }
// angle of vector v from +x axis
ld angle(Pt v){ return atan2(v.y, v.x); }
Pt scale_to(Pt a, ld res){ return a*res/norm(a); }
Pt rotate(Pt a, ld rad){ return {a.x*cos(rad)-a.y*sin(rad), a.x*sin(rad)+a.y*cos(rad)}; }  
Pt normal(Pt a){ ld n=norm(a); return {-a.y/n, a.x/n}; }
ld points_distance(Pt a, Pt b){ return norm(b-a); }
///point_vector
//point_vector_methods
Pt fromPolar(ld len, ld ang){ return {len*cos(ang), len*sin(ang)}; }
ld degtorad(ld deg){ return deg/180*M_PI; }
///point_vector_methods


// LINES ////////////////////////////////////////////////////////////// 

//line
struct Line {
    Pt a, b;
    bool operator<(Line &l){
        Pt v=b-a, w=l.b-l.a;
        return atan2(v.y, v.x) < atan2(w.y, w.x);
    }
};
///line

//lines
ld line_point_dist(Line l, Pt p){ return fabs(vec(p-l.a, l.b-l.a)/norm(l.b-l.a)); }
Pt lines_intersection(Line p, Line q){
    Pt v=p.b-p.a;
    Pt w=q.b-q.a;
    ld t=vec(w, p.a-q.a)/vec(v, w);
    return p.a+v*t;
}
Pt line_point_closest_point(Line a, Pt b){
    return lines_intersection(a, {b, b+normal(a.b-a.a)});
}
bool line_line_equal(Line a, Line b){
    return eq(vec(a.a-b.b, b.a-b.b), 0) && eq(angle(a.b-a.a), angle(b.b-b.a));
}
///lines
//todo test: Pt line_point_closest_point(Line l, Pt a){ Pt v=l.b-l.a; return l.a+v*(dot(v, p-l.a)/norm(v)); }


// SEGMENTS /////////////////////////////////////////////////////////// 

//segment
struct Segment{
    Pt a, b;
    bool operator<(const Segment &q){return a!=q.a ? a<q.a : b<q.b; }
    bool operator==(const Segment &q){return (a==q.a&&b==q.b)||(a==q.b&&b==q.a); }
};
///segment

//segments
bool segment_intersect(Segment s, Segment t){
    ld c1=vec(s.b-s.a, t.a-s.a), c2=vec(s.b-s.a, t.b-s.a);
    ld c3=vec(t.b-t.a, s.a-t.a), c4=vec(t.b-t.a, s.b-t.a);
    return dcmp(c1)*dcmp(c2)<-EPS && dcmp(c3)*dcmp(c4)<-EPS;
}
ld segment_point_distance(Segment s, Pt p){
    if(s.a==s.b) return norm(p-s.a);
    Pt v1=s.b-s.a, v2=p-s.a, v3=p-s.b;
    if(dcmp(dot(v1, v2))<0) return norm(v2);
    if(dcmp(dot(v1, v3))>0) return norm(v3);
    return fabs(vec(v1, v2))/norm(v1);
}
// including endpoints, put <0 if endpoints not included
bool is_point_on_segment(Pt p, Segment s){
    return dcmp(vec(s.a-p, s.b-p))==0 && dcmp(dot(s.a-p, s.b-p))<=0;
}
///segments

//dijkstra
#define INF (1ll<<61)
// result has back pointer and length of shortest path
struct Res{ ll back; ld len; };
struct El{
    ll id;
    ld w;
    bool operator<(const El&e)const{
        return w!=e.w?w>e.w:id<e.id;
    }
};

struct Ne{ ll t; ld w; };
typedef vector<vector<Ne>> Graph;

// graph of nodes with pair (neighbour, weight)
vector<Res> dijkstra(Graph& g, ll start) {
    ll N = g.size();
    vector<Res> res(N, {-1, INF}); // previous, cost
    res[start].back = start;
    res[start].len = 0;
    vector<bool> todo(N, 1);
    // edge weight, target
    priority_queue<El> q;
    q.push({start,0});
    while (!q.empty()) {
        El el = q.top(); q.pop();
        ld basew = el.w;
        ll id = el.id;
        // if (id == end) break; // add parameter if end known
        if (todo[id]) {
            todo[id] = 0;
            for (auto e : g[id]) {
                ll v = e.t;
                ld ne = basew + e.w;
                if (ne < res[v].len) {
                    res[v].back = id;
                    res[v].len = ne;
                    q.push({v,ne});
                }
            }
        }
    }
    return res;
}
///dijkstra


double solve(vector<Polygon> &polygons, Pt S, Pt T){
    vector<Pt> points;
    points.push_back(S);
    points.push_back(T);
    vector<Segment> segments;
    for(Polygon &p:polygons){
        for(Pt a:p)points.push_back(a);
        for(ll i=0; i<p.size()-1; ++i) segments.push_back({p[i],p[i+1]});
        segments.push_back({p[0],p[p.size()-1]});
    }
    vector<Segment> possible_edge;
    for(ll i=0; i<points.size(); ++i){
        for(ll j=0; j<i; ++j){
            bool feasible = true;
            Segment n({points[i],points[j]});
            for(Segment &s:segments){
                if(segment_intersect(n,s)){
                    feasible=false;
                    break;
                }
            }
            if(feasible) possible_edge.push_back(n);
        }
    }
    map<Pt,ll> nodes;
    for(Segment &s:possible_edge){
        if(nodes.count(s.a) == 0){ nodes[s.a] = nodes.size(); }
        if(nodes.count(s.b) == 0){ nodes[s.b] = nodes.size(); }
    }
    Graph graph(nodes.size());
    ll SG = nodes[S];
    ll ST = nodes[T];
    for(Segment &s:possible_edge){
        ll aid = nodes[s.a];
        ll bid = nodes[s.b];
        ld w = points_distance(s.a,s.b);
        graph[aid].push_back({bid,w});
        graph[bid].push_back({aid,w});
    }
    vector<Res> res = dijkstra(graph, SG);
    // for(auto r:res)cout<<r.back<<' ' <<r.len<<endl;
    // cout << res.size() << endl;
    return res[ST].len;
}


int main(){
    ll N; Pt S, T;
    cin >> N >> S.x >> S.y >> T.x >> T.y;
    vector<Polygon> polygons;
    for(ll i=0; i<N; ++i){
        ll M; cin >> M;
        Polygon poly(M);
        for(Pt &a:poly)cin>>a.x>>a.y;
        polygons.push_back(poly);
    }
    cout << solve(polygons, S, T) << endl;
    return 0;
}
