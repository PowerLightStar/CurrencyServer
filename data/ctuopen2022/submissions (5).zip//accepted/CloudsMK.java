import static java.lang.Math.PI;
import static java.lang.Math.atan2;
import static java.lang.Math.hypot;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeSet;


/**
 * ICPC - CTU Open Contest 2022
 * Sample Solution: Clouds
 * 
 * @author Martin Kacer
 */
public class CloudsMK {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	boolean hasNextToken() {
		try {
			while (!st.hasMoreTokens()) {
				String line = input.readLine();
				if (line == null) return false;
				st = new StringTokenizer(line);
			}
		} catch (IOException ex) { throw new RuntimeException(ex); }
		return true;
	}
	String nextToken() {
		return (!hasNextToken()) ? null : st.nextToken();
	}
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	public static void main(String[] args) {
		System.out.println(new CloudsMK().run());
	}
	
	static final double EPS = 1E-11;
	
	static class Line {
		final Point p1, p2;
		final double a1, a2;
		Line(Point q1, Point q2) { p1 = q1; p2 = q2; a1 = atan2(p1.y, p1.x); a2 = atan2(p2.y, p2.x); }
	}
	
	/** Calculate the distance of the point at Line c that lies at a given angle. */
	static double distanceAt(Line c, double a) {
		// find the intersection of a given line with the vector [0,0]--[cos alpha, sin alpha]
		double d0 = (c.p2.y-c.p1.y) * Math.cos(a) - (c.p2.x-c.p1.x) * Math.sin(a);
		double d1 = (c.p2.y-c.p1.y) * c.p1.x - (c.p2.x-c.p1.x) * c.p1.y;
		return d1 / d0;  // that is a unit vector, so the line parameter ("t") directly equals the distance
	}

	/** Comparator that decides which line segment is closer at a given "current angle" (direction).
	 * Although the angle parameter changes across the time, the comparator should yield
	 * consistent results, because no line segments intersect and because it is only
	 * called for line segments that cover the current angle.
	 */
	static class LineComp implements Comparator<Line> {
		double alpha = -PI;
		@Override public int compare(Line o1, Line o2) {
			return Double.compare(distanceAt(o1, alpha), distanceAt(o2, alpha));
		}
	}
	
	static class Event implements Comparable<Event> {
		final Line cld; final boolean first; final double a;
		public Event(Line cc, boolean ff, double aa) { this.cld = cc; this.first = ff; this.a = aa; }
		@Override public int compareTo(Event o) { return Double.compare(a, o.a); }
	}
	
	List<List<Point>> clouds = new ArrayList<>();
	Point start, end;
	Map<Point, Double> state = new HashMap<>();
	
	static boolean isLess(double a1, double a2, double d, double d0) {
		if (Math.abs(a1 - a2) < EPS || Math.abs(a1 - a2) > 2*PI-EPS)
			// angle is the same, prefer the more distant point
			return d > d0;
		return a1 < a2;
	}

	/** Transform one cloud into a line from the left-most to the right-most point. */
	static Line contractCloud(Point ctr, List<Point> cld) {
		Point min = null, max = null, min180 = null, max180 = null;
		double amin = 9, amax = -9, amin180 = 9, amax180 = -9;
		double dmin = 0, dmax = 0, dmin180 = 0, dmax180 = 0;
		if (amin180 < 0) { amin180 += 2*PI; amax180 = amin180; }
		for (Point pp : cld) {
			Point p = new Point(pp.x - ctr.x, pp.y - ctr.y);
			if (p.x == 0 && p.y == 0) continue;
			double a = atan2(p.y, p.x);
			if (isLess(a, amin, p.distance(0, 0), dmin)) { min = p; amin = a; dmin = p.distance(0, 0); }
			if (isLess(amax, a, p.distance(0, 0), dmax)) { max = p; amax = a; dmax = p.distance(0, 0); }
			if (a < 0) a += 2*PI;
			if (isLess(a, amin180, p.distance(0, 0), dmin180)) { min180 = p; amin180 = a; dmin180 = p.distance(0, 0); }
			if (isLess(amax180, a, p.distance(0, 0), dmax180)) { max180 = p; amax180 = a; dmax180 = p.distance(0, 0); }
		}
		if (amin + PI > amax) return new Line(min, max);
		return new Line(min180, max180);
	}
	
	void enqueue(Point p, double dist) {
		//System.err.println("  > " + p + " " + dist);
		Double dd = state.get(p);
		if (dd == null || dist < dd)
			state.put(p, dist);
	}
	
	boolean hides(Line cld, Point p) {
		//System.err.print("  ? " + cld.p1 + "--" + cld.p2 + " hides " + p + " ... ");
		double a2 = (cld.a2 >= cld.a1) ? cld.a2 : cld.a2 + 2*PI;
		double a = atan2(p.y, p.x);
		if (a < cld.a1 - EPS) a += 2*PI;
		if (a > a2 + EPS) return false;
		return distanceAt(cld, a) < hypot(p.x, p.y);
	}
	
	void expandStates(Point ctr, double dist) {
		List<Line> conts = new ArrayList<>(clouds.size());
		for (List<Point> cld : clouds) conts.add(contractCloud(ctr, cld));
		LineComp cmp = new LineComp();
		TreeSet<Line> act = new TreeSet<>(cmp);
		List<Event> evs = new ArrayList<>(conts.size() * 2 + 1);
		for (Line c : conts) {
			if (c.a1 > c.a2) act.add(c);  // add clouds intersecting the "-PI" direction
			evs.add(new Event(c, true, c.a1));
			evs.add(new Event(c, false, c.a2));
		}
		evs.sort(null);
		//System.err.println("  START: " + act.size());
		//for (Line a : act) System.err.println("  " + a.p1 + "--" + a.p2);
		for (Event e : evs) {
			cmp.alpha = e.a;
			Point p = null;
			if (e.first) {
				//System.err.println("  ADD " + e.cld.p1 + "--" + e.cld.p2);
				act.add(e.cld);
				if (act.iterator().next() == e.cld) p = e.cld.p1;
			} else {
				//System.err.println("  REM " + e.cld.p1 + "--" + e.cld.p2);
				if (act.iterator().next() == e.cld) p = e.cld.p2;
				act.remove(e.cld);
			}
			if (p != null) enqueue(new Point(ctr.x + p.x, ctr.y + p.y), dist + hypot(p.x, p.y));
		}
		Point ep = new Point(end.x - ctr.x, end.y - ctr.y);
		for (Line c : conts) {
			if (hides(c, ep)) return;
		}
		enqueue(end, dist + hypot(ep.x, ep.y));
	}
	
	double run() {
		int n = nextInt();
		start = new Point(nextInt(), nextInt());
		end = new Point(nextInt(), nextInt());
		for (int i = 0; i < n; ++i) {
			int c = nextInt();
			List<Point> cc = new ArrayList<>(c);
			while (c-->0) cc.add(new Point(nextInt(), nextInt()));
			clouds.add(cc);
		}
		
		state.put(start, Double.valueOf(0));
		for (;;) {
			Map.Entry<Point,Double> min = state.entrySet().stream().filter(e -> e.getValue() >= 0).min((e,f) -> Double.compare(e.getValue(), f.getValue())).get();
			if (min.getKey().equals(end))
				return min.getValue();
			expandStates(min.getKey(), min.getValue());
			state.put(min.getKey(), Double.valueOf(-1));
		}
	}
}
