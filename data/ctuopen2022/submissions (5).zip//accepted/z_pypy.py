#!/usr/bin/env pypy3
from __future__ import annotations
# BEGIN import dijkstra.py
# Shortest Path: Dijkstra
from heapq import heappush, heappop
class dijkstra:
    """ Dijkstra's shortest path algorithm.

            - Create graph
            - Start algorithm from a start node.
            - Query path length

        Variables:
            graph (list[tuple]): Edges to neighbors (with values).
            parent (list[int]): The parent of each edge during algorithm.
            seen (list[int]): Length from "start" to "node"
            size (int): Number of nodes in graph
    """
    graph = None
    parent = None
    seen = None
    size = None
    def __init__(self, size: int):
        """ Initialisation of class -- creates empty lists of edges.

        Complexity:
            O(size)

        Args:
            size (int): Size of list
        """
        self.size = size
        self.graph = [list() for _ in range(size)]

    def add_uni(self, begin: int, end: int, price: int):
        """ Adds uni-directional edge to the graph

        Args:
            begin (int): Start of the edge.
            end (int): End of the edge.
            price (int): Price of the travel through the edge.

        Complexity:
            O(1)
        """
        self.graph[begin].append((end, price))

    def add_bi(self, first: int, second: int, price: int):
        """ Adds bi-directional edge to the graph

        Args:
            first (int): Start/end of the edge.
            second (int): End/start of the edge.
            price (int): Price of the travel through the edge.

        Complexity:
            O(1)
        """
        self.add_uni(first, second, price)
        self.add_uni(second, first, price)

    def search(self, start: int, operation = lambda a, b: a + b):
        """ Process the graph from start. Find the shortest distance to each possible node.

        Args:
            start (int): The node from which we spread
            operation (function)

        Complexity:
            O(Nlog(M))
        """
        self.parent = [-1]*self.size
        self.seen = [None]*self.size
        p_queue = []
        S = 1
        heappush(p_queue, (0, start))
        self.seen[start] = 0
        while S:
            price, node = heappop(p_queue)
            S-=1
            if self.seen[node] != price: continue
            for neighbor, value in self.graph[node]:
                if self.seen[neighbor] is None or self.seen[neighbor] > operation(price, value):
                    self.parent[neighbor] = node
                    self.seen[neighbor] = operation(price, value)
                    S+=1
                    heappush(p_queue, (operation(price, value), neighbor))

    def path_length(self, destination: int, bad = None) -> int:
        """ Obtains the length of path from "start" to "destination"

        Args:
            destination (int): The final node to which the length is to be obtained.

        Complexity:
            O(1)

        Returns:
            int: Length of path from "start" to "destination".
                None is returned if there is no path.
        """
        if self.seen[destination] is None: return bad
        return self.seen[destination]

# END of import dijkstra.py
# BEGIN import point.py
# 3 Dimensional point with basic operations
import math
class Point:
    """ Class which represents point in 3 dimensions (or 2 if last parameter is not set)

    Variables:
        x (float): X coordinate
        y (float): Y coordinate
        z (float): Z coordinate
        index (int): Identifier of point
    """
    x = None
    y = None
    z = None
    index = None
    def __init__(self, x: float, y: float, z: float = 0, index: int = None):

        """ Initialisation of point by 2 or 3 of its coordinates

        Args:
            x (float): X coordinate of point.
            y (float): Y coordinate of point.
            z (float): Z coordinate of point (defaults to 0).

        Complexity:
            O(1)
        """
        self.x, self.y, self.z = x, y, z
        self.index = index

    def __sub__(self, point: Point) -> Point:
        """ Subtraction operator for two point.

        Args:
            point (Point) Another point which is to be subtracted.

        Note:
            This function does not mangle with class - it creates new one.

        Complexity:
            O(1)

        Returns:
            Point: Result of operation "this point" - "arg point".

        Note:
            This is a scalar operation.
        """
        return Point(self.x-point.x, self.y-point.y, self.z-point.z)

    def __lt__(self, point: Point) -> bool:
        """ Operator "<" between two points. The lower coordinates the lower - priority X -> y -> z.

        Args:
            point (Point): The point with which we want to compare.

        Returns:
            bool: True, if this point is lesser than argument.

        Complexity:
            O(1)
        """
        if self.x != point.x: return self.x < point.x
        if self.y != point.y: return self.y < point.y
        return self.z < point.z

    def __repr__(self) -> str:
        """ Returns better representation of object for debugging.

        Returns:
            str: Representation if form of (x, y, z)

        Complexity:
            O(1)
        """
        return f"({self.x}, {self.y}, {self.z})"

    def dot(self, point: Point) -> float:
        """ Dot product of two points

        Args:
            point (Point): The point to get dot product with

        Complexity:
            O(1)

        Returns:
            float: The dot product of two points.

        Note:
            This is a scalar operation.
        """
        return self.x*point.x + self.y*point.y + self.z*point.z

    def cross(self, point: Point) -> Point:
        """ Cross product of two points

        Args:
            point (Point): The point to get cross product with

        Complexity:
            O(1)

        Returns:
            Point: The cross product of "this point" and "argument point".

        Note:
            This is a vector operation
        """
        return Point(self.y*point.z - self.z*point.y,
                     self.z*point.x - self.x*point.z,
                     self.x*point.y - self.y*point.x)

    def bend(self, second: Point, third: Point) -> int:
        """ Checks whether the angles of two points bend clockwise, anticlockwise or are straight.

        Note:
            The order of points is: This, second and then third.

        Args:
            second (Point): The second point in the angle.
            third (Point): The last point in the angle.

        Returns:
            1: If the angle is anti-clockwise.
            -1: If the angle is clockwise.
            0: If the angle is straight.
        """
        one = second - self
        two = third - self
        cross = one.x * two.y - one.y * two.x
        if cross > 0: return 1
        if cross < 0: return -1
        return 0


    def absolute(self) -> float:
        """ Returns the absolute of Point (|point|).

        Returns:
            float: |point|

        Complexity:
            O(1)
        """
        return pow((self.x ** 2 + self.y ** 2 + self.z ** 2), 0.5)

    def distance(self, point: Point) -> float:
        """ Find distance between two points.

        Args:
            point (Point): The second point to which we are seeking the distance.

        Returns:
            float: Distance between points.

        Complexity:
            O(1)
        """
        return math.sqrt(pow(self.x-point.x, 2)+
                         pow(self.y-point.y, 2)+
                         pow(self.z-point.z, 2))
# END of import point.py
# BEGIN import convex_hull.py
# Class for creation of convex hull
class convexHull:
    """ Data structure which accepts points (2D) and creates convex hull from them.

    Requires:
        import Point

    Variables:
        hull (list[point]): List with result convex hull.
        points (list[points]): list with points added to the data structure.

    Note:
        Structure uses Andrew's algorithm.
    """
    hull = None
    points = None
    def __init__(self):
        """ Creates points list.

        Complexity:
            O(1)
        """
        self.points = []

    def add_point(self, point: Point):
        """ Adds point to list with inserted points.

        Complexity:
            O(1)

        Args:
            points (Point): 2D point to be added.
        """
        self.points.append(point)

    def convex_hull(self):
        """ Creates convex hull.

        Complexity:
            O(NlogN))

        Note:
            First point will be duplicated as last point
        """
        self.hull = []
        if len(self.points) < 2:
            self.hull = list(self.points)
            return
        self.points.sort()
        for point in self.points:
            while len(self.hull) > 1 and self.hull[-2].bend(self.hull[-1], point) == -1:
                self.hull.pop()
            self.hull.append(point)
        self.points.reverse()
        total = len(self.hull)
        for point in self.points[1:]:
            while len(self.hull) > total and self.hull[-2].bend(self.hull[-1], point) == -1:
                self.hull.pop()
            self.hull.append(point)

    def get_perimeter(self) -> float:
        """ Gets perimeter of found convex hull.

        Complexity:
            O(hull-size)

        Returns:
            float: Perimeter of convex hull.
        """
        return sum([self.hull[i].distance(self.hull[i+1]) for i in range(len(self.hull)-1)])

    def get_hull(self) -> list(Point):
        """ Returns the convex hull.

        Note:
            Every point is returned once even though one of them is twice in the original representation.

        Complexity:
            O(1)

        Returns:
            list(Point): Convex hull starting from leftmost point.
        """
        return self.hull[:-1]

# END of import convex_hull.py
# Points intersection
def lines_intersection(first: tuple, second: tuple) -> bool:
    """ Check if two lines (tuples of points) intersect

    Args:
        first (tuple(Point, Point)): First line.
        second (tuple(Point, Point)): Second line.

    Returns:
        bool: True of the lines intersect

    Complexity:
        O(1)
    """
    def get_side(one: Point, two: Point, three: Point) -> int:
        """ Check the side of third point (left/right/collinear)"""
        side = (two - one).y * (three - two).x - (three - two).y * (two - one).x
        if not side: return 0
        return -1 if side < 0 else 1

    def is_between(one: Point, two: Point, three: Point) -> bool:
        """ Checks if second point is in square formed by min/max coordinates of other points."""
        if two.x > max(one.x, three.x): return False
        if two.x < min(one.x, three.x): return False
        if two.y > max(one.y, three.y): return False
        if two.y < min(one.y, three.y): return False
        return True

    A, B = first
    C, D = second
    a, b, c, d = get_side(A, B, C), get_side(A, B, D), get_side(C, D, A), get_side(C, D, B)
    if a != b and c != d: return True
    if not a and is_between(A, C, B): return True
    if not b and is_between(A, D, B): return True
    if not c and is_between(C, A ,D): return True
    if not d and is_between(C, B, D): return True
    return False

import sys
sys.setrecursionlimit(1000000)
def D(a):print(a)
def line():return sys.stdin.readline().strip()
def next_int():return int(line())
def line_ints():return list(map(int,line().split(" ")))
# Parse input
N, X, Y, x, y = line_ints()
T = 2
P = Point(X, Y, index=0)
p = Point(x, y, index=1)
H = []
O = [p, P]
for j in range(N):
    h = convexHull()
    A = line_ints()
    for i in range(1, A[0]*2+1, 2):
        h.add_point(Point(A[i], A[i+1], index = T))
        T+=1
    h.convex_hull()
    H.append(h)
# Create graph
l = [-1]*T
l[0] = -2
G = dijkstra(T)
for j, h in enumerate(H):
    A=h.get_hull()
    for i in range(len(A)):
        I=(i+1)%len(A)
        G.add_bi(A[i].index, A[I].index, A[I].distance(A[i]))
        O.append(A[i])
        l[A[i].index] = j

def ok(X, Y):
    if l[X.index] == l[Y.index]: return False
    global H
    for h in H:
        A = h.get_hull()
        for i in range(len(A)):
            I = (i+1) % len(A)
            a, b = A[i], A[I]
            if a == X or a == Y or b == X or b == Y: continue
            if lines_intersection((X, Y),(a, b)):
                return False
    return True

for i in range(len(O)):
    for j in range(i):
#        D(f"    {O[j]} -> {O[i]} : {ok(O[i], O[j])}") #TODO ERASE
        if ok(O[i], O[j]):
            G.add_bi(O[i].index, O[j].index, O[i].distance(O[j]))
G.search(0)
D(f"{G.path_length(1):.8f}")

