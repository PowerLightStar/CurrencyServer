#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef double ld;

#define EPS (1e-10)
#ifndef M_PI
#define M_PI acos(-1.)
#endif

// POINTS ///////////////////////////////////////////////////////////// 

struct Pt{
    ll x, y;
    bool operator <(const Pt &p) const { return x < p.x || (x == p.x && y < p.y); }
    Pt operator+(const Pt &p){ return{x+p.x, y+p.y}; }
    Pt operator-(const Pt &p){ return{x-p.x, y-p.y}; }
    Pt operator-(){ return{-x, -y}; }
    bool operator==(const Pt &p)const{ return x==p.x && y==p.y; }
    bool operator!=(const Pt &p)const{ return x!=p.x || y!=p.y; }
    friend ostream &operator<<(ostream &os, const Pt &a){ os<<a.x<<' '<<a.y; return os; }
    friend istream &operator>>(istream &is, Pt &a){ is>>a.x>>a.y; return is; }
};
namespace std {
    template <> struct hash<Pt> {
        size_t operator()(const Pt &a) const { return (hash<ld>()(a.x) ^ hash<ld>()(a.y)); }
    };
}
typedef vector<Pt> Polygon;

ll vec(Pt a, Pt b){ return a.x*b.y-a.y*b.x; }
ll vec(Pt a, Pt b, Pt c){ return vec(b-a, c-a); }
ld norm(Pt a){ return hypot(a.x, a.y); }
ld points_distance(Pt a, Pt b){ return norm(b-a); }
ld angle(Pt v){ return atan2(v.y, v.x); }

struct Segment{
    Pt a, b;
};

ll dcmp(ll val){
    return (val==0)?0:(val>0?1:-1);
}

// DIJKSTRA /////////////////////////////////////////////////////////// 

#define INF (1ll<<61)
// result has back pointer and length of shortest path
struct Res{ ll back; ld len; };
struct El{
    ll id;
    ld w;
    bool operator<(const El&e)const{
        return w!=e.w?w>e.w:id<e.id;
    }
};

struct Ne{ ll t; ld w; };
typedef vector<vector<Ne>> Graph;

// graph of nodes with pair (neighbour, weight)
vector<Res> dijkstra(Graph& g, ll start) {
    ll N = g.size();
    vector<Res> res(N, {-1, INF}); // previous, cost
    res[start].back = start;
    res[start].len = 0;
    vector<bool> todo(N, 1);
    // edge weight, target
    priority_queue<El> q;
    q.push({start,0});
    while (!q.empty()) {
        El el = q.top(); q.pop();
        ld basew = el.w;
        ll id = el.id;
        // if (id == end) break; // add parameter if end known
        if (todo[id]) {
            todo[id] = 0;
            for (auto e : g[id]) {
                ll v = e.t;
                ld ne = basew + e.w;
                if (ne < res[v].len) {
                    res[v].back = id;
                    res[v].len = ne;
                    q.push({v,ne});
                }
            }
        }
    }
    return res;
}
///dijkstra

//conhull
struct Cmp{
    bool operator()(const Pt&a, const Pt&b)const{
        return (a.x != b.x) ? a.x < b.x : a.y < b.y;
    }
};

vector<Pt> convex_hull(vector<Pt> p) {
    vector<Pt> r(2 * p.size() + 14);
    ll K = 0;
    sort(p.begin(), p.end(), Cmp());
    for(Pt e:p){
        while (K >= 2 && vec(r[K-1]-r[K-2], e-r[K-2]) <= 0) K--;
        r[K++] = e;
    }
    for(ll i=p.size()-2, T=K+1; i>=0; i--){
        while (K >= T && vec(r[K-1]-r[K-2], p[i]-r[K-2]) <= 0) K--;
        r[K++] = p[i];
    }
    r.resize(K);
    r.pop_back();
    return r;
}
///conhull

// put angle a to range 0-2PI and b to be 0-2PI bigger than a
void normalize_angle(ld &a, ld &b){
    while(a<0)a+=2*M_PI;
    while(b<a)b+=2*M_PI;
}

struct Range{
    bool start;
    Pt point;
    ll polyid;
};

// identify what are corners from the view-point of 'o'
vector<pair<ll,ll>> identify_corners(Pt o, vector<pair<Pt,ll>> &all_points, ll polygon_count){
    vector<pair<ll,ll>> corners(polygon_count,{-1,-1});
    sort(all_points.begin(),all_points.end(), [o](auto &a,auto &b){
        return angle(a.first-o) < angle(b.first-o);
    });
    // for(auto &p:all_points)cout<<"["<<p.first<<"]"<<p.second<<", ";cout<<endl;
    vector<ll> last_id(polygon_count,-1);
    for(ll j=0; j<2*all_points.size(); ++j){
        ll i=j%all_points.size();
        auto q=all_points[i];
        Pt p=q.first;
        ll polyid=q.second;
        if(corners[polyid].first==-1 && last_id[polyid]!=-1){
            ld aang=angle(all_points[last_id[polyid]].first-o);
            ld bang=angle(p-o);
            normalize_angle(aang,bang);
            if(bang-aang > M_PI || all_points[last_id[polyid]].first == p){ // for the degenerated case
                corners[polyid] = {i,last_id[polyid]};
            }
        }
        last_id[polyid]=i;
    }
    return corners;
}

// returns a list of points where vertex 'o' should connect to allow shortest s-t path
// previous, origin, next, all points that should be considered, total number of polygons
vector<Pt> feasible_points(Pt p, Pt o, Pt n, vector<pair<Pt,ll>> &all_points, ll polygon_count){
    // cout << "\n\nfor point " << o << endl;
    auto corners=identify_corners(o, all_points, polygon_count);
    // with corners in hand we sort them so we can sweep
    vector<Range> range_points;
    for(auto &c:corners){
        if(c.first!=-1){
            range_points.push_back(Range{true,all_points[c.first].first,all_points[c.first].second});
            range_points.push_back(Range{false,all_points[c.second].first,all_points[c.second].second});
        }
        // cout << "corners: ";
        // if(c.first!=-1)cout << all_points[c.first].first << ' ';else cout<<"- ";
        // if(c.second!=-1)cout << all_points[c.second].first << ' ';else cout<<"- ";
        // cout << endl;
    }
    sort(range_points.begin(),range_points.end(), [o](auto a,auto b){
        ld aang=angle(a.point-o);
        ld bang=angle(b.point-o);
        // return aang < bang;
        return aang!=bang ? aang < bang : (a.start && !b.start);
    });
    // for(Range r:range_points){ cout << r.polyid << ' ' << r.start << " [" << r.point << "] " << angle(r.point-o) << endl; }
    // during the sweep we aim to detect which polygon is the closest one
    auto cmp = [&](const pair<Segment,ll>& pl, const pair<Segment,ll>& pr) {
        const Segment &l = pl.first;
        const Segment &r = pr.first;
        // cout << "comparing " << pl.second << " with " << pr.second << endl;
        // cout << l.a << ' ' << l.b << ' ' << r.a << ' ' << r.b << endl;
        if(l.a == l.b || r.a == r.b){ // degenerated case where pl or pr is S or T
            if(l.a == l.b && r.a == r.b){ // it is S and T, then distance decides
                return points_distance(o,l.a) < points_distance(o,r.a);
            }else{
                bool res;
                if(r.a == r.b){
                    res = dcmp(vec(l.a, l.b, r.a)) != dcmp(vec(l.a, l.b, o));
                }else{
                    res = dcmp(vec(r.a, r.b, l.a)) == dcmp(vec(r.a, r.b, o));
                }
                // cout << "degenerated " << l.a << ' ' << l.b << ' ' << r.a << ' ' << r.b << " -> " << res << endl;
                return res;
            }
        }
        // two line segments represent the two polygons
        // first, see how they separate the space with respect to the origin
        // split is 1 if it is on the same side as the origin
        ll split_lra = dcmp(vec(l.a, l.b, r.a)) * dcmp(vec(l.a, l.b, o));
        ll split_lrb = dcmp(vec(l.a, l.b, r.b)) * dcmp(vec(l.a, l.b, o));
        ll split_rla = dcmp(vec(r.a, r.b, l.a)) * dcmp(vec(r.a, r.b, o));
        ll split_rlb = dcmp(vec(r.a, r.b, l.b)) * dcmp(vec(r.a, r.b, o));
        // cout << "splits: " << split_lra << ' ' << split_lrb << ' ' << split_rla << ' ' << split_rlb << endl;
        // separate is true if the line separates the other one from the origin
        bool l_separates_r = split_lra == -1 && split_lrb == -1;
        bool r_separates_l = split_rla == -1 && split_rlb == -1;
        if(l_separates_r && r_separates_l){ // from 'o's point-of-view they are disjoint, so we do not care
            return pl.second < pr.second;
            // return min(points_distance(o,l.a),points_distance(o,l.b)) < min(points_distance(o,r.a),points_distance(o,r.b));
        }
        // if l separates r then it is closer
        if(l_separates_r) return true;
        if(r_separates_l) return false;
        // align is true if the line is 'behind' the other one from the point-of-view of 'o'
        bool l_aligns_r = split_lra == 1 && split_lrb == 1;
        bool r_aligns_l = split_rla == 1 && split_rlb == 1;
        // if l aligns r then it is further
        if(l_aligns_r && r_aligns_l){ // from 'o's point-of-view they are disjoint, so we do not care
            return pl.second < pr.second;
        }
        if(l_aligns_r) return false;
        if(r_aligns_l) return true;
        // as they do not separate or align it means that mutually they are either colinear with each other, colinear with the origin, or cut each other; as they cannot cut each other mutually they are colinear with each other or with the origin; hence, they are disjoint from point-of-view or 'o' so we just take the closer one
        return pl.second < pr.second;
    };
    // now we can sweep through ranges and update the current order
    set<pair<Segment,ll>, decltype(cmp)> current_polygons(cmp);
    // Range: bool start; // Pt point; // ll polyid;
    vector<Pt> res;
    ld pang= p!=o ? angle(p-o) : 0; // angle to previous vertex on my polygon
    ld nang= n!=o ? angle(n-o) : 0; // angle to next vertex on my polygon
    normalize_angle(pang,nang);
    // cout << pang << ' ' << nang << endl;
    for(ll iteration=0; iteration<2; ++iteration){
        // has cold start, initialize property by going through one time
        // perform the actual computation when going through the second time
        for(Range &r:range_points){
            // cout << r.point << ' ' << r.start << endl;
            auto c=corners[r.polyid];
            pair<Segment,ll> s=make_pair(Segment{all_points[c.first].first,all_points[c.second].first}, r.polyid);
            if(r.start){
                // cout << "add    " << r.polyid << endl;
                current_polygons.insert(s);
                if(iteration==1 && current_polygons.begin()->second == r.polyid){
                    // cout << "check: " << r.point << endl;
                    ld ang=angle(r.point-o);
                    while(ang<pang)ang+=2*M_PI;
                    // cout << "angles: " << pang << ' ' << ang << ' ' << nang << endl;
                    if(pang <= ang+EPS && ang <= nang+EPS || pang==nang){ // for degenerate case
                        // cout << "yes\n";
                        res.push_back(r.point);
                    }
                }
            }else{
                if(iteration==1 && current_polygons.begin()->second == r.polyid){
                    // cout << "check: " << r.point << endl;
                    ld ang=angle(r.point-o);
                    while(ang<pang)ang+=2*M_PI;
                    if(pang <= ang+EPS && ang <= nang+EPS || pang==nang){
                        // cout << "yes\n";
                        res.push_back(r.point);
                    }
                }
                const auto it=current_polygons.find(s);
                if(it != current_polygons.end()){
                    // cout << "remove " << r.polyid << endl;
                    current_polygons.erase(it);
                }else{
                    // cout << "would remove " << r.polyid << endl;
                }
            }
            if(!current_polygons.empty()){
                // cout << "current first set element: " << current_polygons.begin()->second << endl;
            }
        }
    }
    return res;
}

double solve(vector<Polygon> &polygons, Pt S, Pt T){
    vector<vector<Segment>> segments(polygons.size());
    for(ll i=0; i<polygons.size(); ++i){
        Polygon &p=polygons[i];
        for(ll j=0; j<p.size()-1; ++j) segments[i].push_back({p[j],p[j+1]});
        segments[i].push_back({p[p.size()-1],p[0]});
    }
    vector<Segment> possible_edge;
    for(auto &seg:segments) for(Segment s:seg) possible_edge.push_back(s);
    // dummy polygons for start and end
    Polygon spoly; spoly.push_back(S);
    polygons.push_back(spoly);
    Polygon tpoly; tpoly.push_back(T);
    polygons.push_back(tpoly);
    for(ll i=0; i<polygons.size(); ++i){
        vector<pair<Pt,ll>> all_points;
        for(ll j=0; j<polygons.size(); ++j){
            if(j==i)continue;
            for(Pt p:polygons[j])all_points.push_back({p,j});
        }
        ll M=polygons[i].size();
        for(ll j=0; j<M; ++j){
            Pt o=polygons[i][j];
            Pt p=polygons[i][(j+M-1)%M];
            Pt n=polygons[i][(j+1)%M];
            auto res=feasible_points(p,o,n,all_points,polygons.size());
            for(auto t:res) possible_edge.push_back({o,t});
        }
    }

    map<Pt,ll> nodes;
    ll idx=0;
    for(ll i=0; i<polygons.size(); ++i){
        for(Pt &a:polygons[i]){
            nodes[a]=idx++;
        }
    }
    vector<Pt> idx_ton(nodes.size());
    for(auto &p:nodes) idx_ton[p.second]=p.first;
    Graph graph(nodes.size());
    for(Segment &s:possible_edge){
        ll aid = nodes[s.a];
        ll bid = nodes[s.b];
        ld w = points_distance(s.a,s.b);
        graph[aid].push_back({bid,w});
        graph[bid].push_back({aid,w});
    }
    ll SG = nodes[S];
    ll ST = nodes[T];
    vector<Res> res = dijkstra(graph, SG);
    idx=ST;
    vector<Pt> path;
    while(true){
        assert(idx!=-1);
        Pt p=idx_ton[idx];
        path.push_back(p);
        if(idx==SG) break;
        idx = res[idx].back;
    }
    reverse(path.begin(),path.end());
    cerr << path.size() << endl;
    for(Pt &p:path) cerr << p << endl;
    cerr << possible_edge.size() << endl;
    for(Segment &s:possible_edge) cerr << s.a << ' ' << s.b << endl;
    return res[ST].len;
}

int main(){
    ll N; Pt S, T;
    cin >> N >> S.x >> S.y >> T.x >> T.y;
    vector<Polygon> polygons;
    for(ll i=0; i<N; ++i){
        ll M; cin >> M;
        Polygon poly(M);
        for(Pt &a:poly)cin>>a.x>>a.y;
        polygons.push_back(convex_hull(poly));
    }
    cout << fixed << setprecision(10);
    cout << solve(polygons, S, T) << endl;
    return 0;
}
