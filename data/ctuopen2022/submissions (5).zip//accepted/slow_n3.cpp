#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef double ld;

#define EPS (1e-10)

// POINTS ///////////////////////////////////////////////////////////// 

struct Pt{
    ll x, y;
    bool operator <(const Pt &p) const { return x < p.x || (x == p.x && y < p.y); }
    Pt operator+(const Pt &p){ return{x+p.x, y+p.y}; }
    Pt operator-(const Pt &p){ return{x-p.x, y-p.y}; }
    Pt operator-(){ return{-x, -y}; }
    friend ostream &operator<<(ostream &os, const Pt &a){ os<<a.x<<' '<<a.y; return os; }
    friend istream &operator>>(istream &is, Pt &a){ is>>a.x>>a.y; return is; }
};
namespace std {
    template <> struct hash<Pt> {
        size_t operator()(const Pt &a) const { return (hash<ld>()(a.x) ^ hash<ld>()(a.y)); }
    };
}
typedef vector<Pt> Polygon;

ll vec(Pt a, Pt b){ return a.x*b.y-a.y*b.x; }
ll vec(Pt a, Pt b, Pt c){ return vec(b-a, c-a); }
ll dot(Pt a, Pt b){ return a.x*b.x+a.y*b.y; }
ld norm(Pt a){ return hypot(a.x, a.y); }
ld points_distance(Pt a, Pt b){ return norm(b-a); }

// SEGMENTS /////////////////////////////////////////////////////////// 

struct Segment{
    Pt a, b;
};

ll dcmp(ll val){
    return (val==0)?0:(val>0?1:-1);
}

bool segment_intersect(Segment s, Segment t){
    if(   points_distance(s.a,t.a)<EPS
       || points_distance(s.b,t.a)<EPS
       || points_distance(s.a,t.b)<EPS
       || points_distance(s.b,t.b)<EPS)
        return false;
    ll c1=vec(s.a,s.b,t.a), c2=vec(s.a,s.b,t.b);
    ll c3=vec(t.a,t.b,s.a), c4=vec(t.a,t.b,s.b);
    if(dcmp(c1)==0&&dcmp(c2)==0&&dcmp(c3)==0&&dcmp(c4)==0) return false;
    return dcmp(c1)*dcmp(c2)<=0 && dcmp(c3)*dcmp(c4)<=0;
}

// DIJKSTRA /////////////////////////////////////////////////////////// 

#define INF (1ll<<61)
// result has back pointer and length of shortest path
struct Res{ ll back; ld len; };
struct El{
    ll id;
    ld w;
    bool operator<(const El&e)const{
        return w!=e.w?w>e.w:id<e.id;
    }
};

struct Ne{ ll t; ld w; };
typedef vector<vector<Ne>> Graph;

// graph of nodes with pair (neighbour, weight)
vector<Res> dijkstra(Graph& g, ll start) {
    ll N = g.size();
    vector<Res> res(N, {-1, INF}); // previous, cost
    res[start].back = start;
    res[start].len = 0;
    vector<bool> todo(N, 1);
    // edge weight, target
    priority_queue<El> q;
    q.push({start,0});
    while (!q.empty()) {
        El el = q.top(); q.pop();
        ld basew = el.w;
        ll id = el.id;
        // if (id == end) break; // add parameter if end known
        if (todo[id]) {
            todo[id] = 0;
            for (auto e : g[id]) {
                ll v = e.t;
                ld ne = basew + e.w;
                if (ne < res[v].len) {
                    res[v].back = id;
                    res[v].len = ne;
                    q.push({v,ne});
                }
            }
        }
    }
    return res;
}
///dijkstra

//conhull
struct Cmp{
    bool operator()(const Pt&a, const Pt&b)const{
        return (a.x != b.x) ? a.x < b.x : a.y < b.y;
    }
};

vector<Pt> convex_hull(vector<Pt> p) {
    vector<Pt> r(2 * p.size() + 14);
    ll K = 0;
    sort(p.begin(), p.end(), Cmp());
    for(Pt e:p){
        while (K >= 2 && vec(r[K-1]-r[K-2], e-r[K-2]) <= 0) K--;
        r[K++] = e;
    }
    for(ll i=p.size()-2, T=K+1; i>=0; i--){
        while (K >= T && vec(r[K-1]-r[K-2], p[i]-r[K-2]) <= 0) K--;
        r[K++] = p[i];
    }
    r.resize(K);
    r.pop_back();
    return r;
}
///conhull


double solve(vector<Polygon> &polygons, Pt S, Pt T){
    vector<vector<Segment>> segments(polygons.size());
    for(ll i=0; i<polygons.size(); ++i){
        Polygon &p=polygons[i];
        for(ll j=0; j<p.size()-1; ++j) segments[i].push_back({p[j],p[j+1]});
        segments[i].push_back({p[p.size()-1],p[0]});
    }
    vector<Segment> candidates;
    candidates.push_back({S,T});
    for(ll i=0; i<polygons.size(); ++i){
        for(Segment s:segments[i]) candidates.push_back(s);
        for(Pt a:polygons[i]){
            candidates.push_back({a,S});
            candidates.push_back({a,T});
        }
        for(ll j=0; j<i; ++j){
            for(Pt a:polygons[i]){
                for(Pt b:polygons[j]){
                    candidates.push_back({a,b});
                }
            }
        }
    }
    vector<Segment> possible_edge;
    for(Segment &n:candidates){
        bool feasible = true;
        for(auto &ss:segments)for(auto &s:ss){
            if(segment_intersect(n,s)){
                feasible=false;
                goto forendsegments;
            }
        }
forendsegments:
        if(feasible) possible_edge.push_back(n);
    }

    map<Pt,ll> nodes;
    ll idx=0;
    nodes[S]=idx++;
    nodes[T]=idx++;
    for(ll i=0; i<polygons.size(); ++i){
        for(Pt &a:polygons[i]){
            nodes[a]=idx++;
        }
    }
    vector<Pt> idx_ton(nodes.size());
    for(auto &p:nodes) idx_ton[p.second]=p.first;
    Graph graph(nodes.size());
    for(Segment &s:possible_edge){
        ll aid = nodes[s.a];
        ll bid = nodes[s.b];
        ld w = points_distance(s.a,s.b);
        graph[aid].push_back({bid,w});
        graph[bid].push_back({aid,w});
    }
    ll SG = nodes[S];
    ll ST = nodes[T];
    vector<Res> res = dijkstra(graph, SG);
    idx=ST;
    vector<Pt> path;
    while(true){
        assert(idx!=-1);
        Pt p=idx_ton[idx];
        path.push_back(p);
        if(idx==SG) break;
        idx = res[idx].back;
    }
    reverse(path.begin(),path.end());
    cerr << path.size() << endl;
    for(Pt &p:path) cerr << p.x << ' ' << p.y << endl;
    return res[ST].len;
}


int main(){
    ll N; Pt S, T;
    cin >> N >> S.x >> S.y >> T.x >> T.y;
    vector<Polygon> polygons;
    for(ll i=0; i<N; ++i){
        ll M; cin >> M;
        Polygon poly(M);
        for(Pt &a:poly)cin>>a.x>>a.y;
        polygons.push_back(convex_hull(poly));
    }
    cout << fixed << setprecision(10);
    cout << solve(polygons, S, T) << endl;
    return 0;
}
