#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'

//#define dbg if(0)cerr

int main(){
  ios::sync_with_stdio(0);cin.tie(0);
  ll n;
  cin>>n;

  // has -> opt
  map<ll,ll> dp;
  dp[-1]=0;
  for (int i = 0; i < n; ++ i) {
    ll m;
    cin>>m;
    vector<pair<ll,ll>> tmp(m);
    for (int j = 0; j < m; ++ j) {
      ll t,p;
      cin>>t>>p;
      tmp[j] = {t, p};
      if (dp.count(t)) {
        dp[-1] = max(dp[-1], dp[t] + p);
      }
    }
    for (int j = 0; j < m; ++ j) {
      ll t = tmp[j].aa;
      ll p = tmp[j].bb;
      if (!dp.count(t)) dp[t] = dp[-1] - p;
      else dp[t] = max(dp[t], dp[-1] - p);
    }
  }
  out(dp[-1]);

  return 0;
}
