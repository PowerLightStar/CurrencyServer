import fileinput
import sys
def D(a):print(a)
def S(s,I):return int(s.split(" ")[I])
sys.setrecursionlimit(200000)
z=-1
x=-1
for l in fileinput.input():
    if z==-1:
        N=int(l)
        z=0
        L=[0]*N
        I=[[0]*10 for i in range(N)]
        V=[[0]*10 for i in range(N)]
        P=[[0]*10 for i in range(N)]
        D=[[-1]*11 for i in range(N)]
        continue
    if z==0:
        x+=1
        L[x]=int(l)
        z=int(l)
        continue
    z-=1
    I[x][z]=S(l,0)
    V[x][z]=S(l,1)

W=dict()
for i in range(N-1, -1, -1):
    for j in range(L[i]):
        P[i][j] = W[I[i][j]] if I[i][j] in W else (N, 10)
        W[I[i][j]]=(i,j)

def dyn(x, d):
    global N, D, L, I, P, V
    if x==N:return 0;
    if D[x][d] != -1:
        return D[x][d]
    D[x][d]=0
    if d < 10:
        D[x][d] = max(D[x][d], V[x][d] + dyn(x, 10), dyn(P[x][d][0], P[x][d][1]))
    else:
        D[x][d] = max(D[x][d], dyn(x+1, d))
        for i in range(L[x]):
            D[x][d] = max(D[x][d], dyn(P[x][i][0], P[x][i][1]) - V[x][i])
    return D[x][d]

print(dyn(0,10))
