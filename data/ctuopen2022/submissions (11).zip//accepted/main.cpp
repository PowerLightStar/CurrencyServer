#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define ZERO (1e-10)
#define INF int(1e9+1)
#define CL(A,I) (memset(A,I,sizeof(A)))
#define DEB printf("DEB!\n");
#define D(X) cout<<"  "<<#X": "<<X<<endl;
#define EQ(A,B) (A+ZERO>B&&A-ZERO<B)
typedef long long ll;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
#define IN(n) int n;scanf("%d",&n);
#define FOR(i, m, n) for (int i(m); i < n; i++)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define FT(m, n) FOR(k, m, n)
#define aa first
#define bb second
void ga(int N,int *A){F(N)scanf("%d",A+i);}
#define MX int(1e5)
#define MI 10
int N,I[MX][MI], V[MX][MI], L[MX], D[MX][MI+1];
ii P[MX][MI];
map<int, ii> W;
int dyn(int x,int d){
    if(x==N)return 0;
    int &w=D[x][d];
    if(~w)return w;
    w=0;
    if(d^MI)w=max(V[x][d]+dyn(x,MI),dyn(P[x][d].aa, P[x][d].bb));
    else{
        w=max(w, dyn(x+1, d));
        F(L[x])w=max(w, dyn(P[x][i].aa, P[x][i].bb) - V[x][i]);
    }
    return w;
}
int main(void){
    CL(D,-1);
    scanf("%d",&N);
    F(N){
        scanf("%d", L+i);
        FF(L[i])scanf("%d%d", I[i]+j, V[i]+j);
    }
    for(int i=N-1;~i;--i)
        FF(L[i]){
            P[i][j]=W.count(I[i][j])?W[I[i][j]]:ii(N,MI);
            W[I[i][j]]={i,j};
        }
    printf("%d\n", dyn(0, MI));
    return 0;
}
