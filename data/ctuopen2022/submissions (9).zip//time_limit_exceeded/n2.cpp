#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'

struct TrieVertex {
  vector<int> edges;
  TrieVertex(): edges(vector<int>(255, -1)) {}
  // problem specific
  int val = 0;
};

struct Trie {
  vector<TrieVertex> v;
  // return values found while passing
  ll insert(const string & str, int i=0, ll vi=0) {
    //dbg << str << ' ' << i << ' ' << vi << ' ' << v[vi].val << endl;
    ll res = v[vi].val;
    if (i >= (int)str.size()) return res;

    if (v[vi].edges[str[i]] != -1) {
      ll next = v[vi].edges[str[i]];
      res += insert(str, i+1, next);
      v[next].val ++;
    } else {
      v.emplace_back(TrieVertex());
      ll idx = v.size()-1;
      v[vi].edges[ str[i] ] = idx;
      res += insert(str, i + 1, v.size()-1);
      v[idx].val++;
    }
    return res;
  }

  // actually only decreases the values. Assumes the string is present.
  ll erase(const string & str, int i=0, ll vi=0) {
    ll res = v[vi].val;
    if (i >= (int)str.size()) return res;
    ll next = v[vi].edges[str[i]];
    v[next].val --;
    res += erase(str, i+1, next);
    return res;
  }

  Trie() {
    v.emplace_back(TrieVertex());
  }
};

int main(){
  ll n,k;
  cin>>n>>k;
  vector<string> s(n);
  F(n){
    cin>>s[i];
    //for(char & j: s[i]) j -= 'a';
  }
  ll r=0;
  ll sum=0;
  ll res=0;
  for (int l=0;l<n;++l) {
    Trie tr;
    ll sum=0;
    for (int r=l;r<n;++r) {
      sum += tr.insert(s[r]);
      if (sum >= k) {
        res++;
      }
    }
  }
  out(res);
}
