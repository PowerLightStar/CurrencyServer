#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define MOD2 ((ll)(1e9+9))
#define dbg cerr
#define out(n) cout << n << '\n'
#define PRIME 257

inline ll comb(ll a, ll b) {
  return (a << 32) ^ b;
}

int main(){
  ll n,k;
  cin>>n>>k;
  vector<string> s(n);
  F(n){
    cin>>s[i];
  }
  ll r=0;
  ll val = 0;
  ll res=0;
  unordered_map<ll,ll> prefixes;

  ll substr=0;
  ll substr2=0;
  for (int i = 0; i < s[r].size(); ++ i) {
    substr = (substr*PRIME + s[r][i])%MOD;
    substr2 = (substr2*PRIME + s[r][i])%MOD2;
    ll h = comb(substr, substr2);
    prefixes[h] ++;
  }

  for (int l=0;l<n;++l) {
    if (l > 0) { // remove the previous one
      for (int i = 0; i < s[l-1].size(); ++ i) {
        ll substr=0;
        ll substr2=0;
        for (int j = 0; j <= i; ++ j) {
          substr = (substr*PRIME + s[l-1][j])%MOD;
          substr2 = (substr2*PRIME + s[l-1][j])%MOD2;
        }
        ll h = comb(substr, substr2);
        prefixes[h] --;
        val -= prefixes[h];
      }
    }
    while (val < k && r < n-1) {
      r ++;
      ll substr=0;
      ll substr2=0;
      for (int i = 0; i < s[r].size(); ++ i) {
        substr = (substr*PRIME + s[r][i])%MOD;
        substr2 = (substr2*PRIME + s[r][i])%MOD2;
        ll h = comb(substr, substr2);
        val += prefixes[h];
        prefixes[h] ++;
      }
    }
    if (val >= k) res += n - r;
  }
  out(res);
}
