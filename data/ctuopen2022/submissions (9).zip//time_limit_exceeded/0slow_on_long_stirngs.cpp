#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'

int main(){
  ll n,k;
  cin>>n>>k;
  vector<string> s(n);
  F(n){
    cin>>s[i];
    //for(char & j: s[i]) j -= 'a';
  }
  ll r=0;
  ll val = 0;
  ll res=0;
  unordered_map<string,ll> prefixes;

  string substr;
  for (int i = 0; i < s[r].size(); ++ i) {
    substr.push_back(s[r][i]);
    val += prefixes[substr];
    prefixes[substr] ++;
  }

  for (int l=0;l<n;++l) {
    if (l > 0) { // remove the previous one
      string substr;
      for (int i = 0; i < s[l-1].size(); ++ i) {
        substr.push_back(s[l-1][i]);
        prefixes[substr] --;
        val -= prefixes[substr];
      }
    }
    while (val < k && r < n-1) {
      r ++;
      string substr;
      for (int i = 0; i < s[r].size(); ++ i) {
        substr.push_back(s[r][i]);
        val += prefixes[substr];
        prefixes[substr] ++;
      }
    }
    /*for (auto i: prefixes) {
      dbg << l << ' ' << r << ": " << i.aa << " " << i.bb << endl;
    }
    dbg << val << endl;*/
    if (val >= k) res += n - r;
    //dbg << res << endl;
    //dbg << res << endl;
  }
  out(res);
}
