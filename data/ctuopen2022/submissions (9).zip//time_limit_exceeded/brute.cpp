#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define dbg cerr
#define out(n) cout << n << '\n'

//#define dbg if(0)cerr

ll cost(const string & a, const string & b) {
  ll res = 0;
  for (int i = 0; i < min(a.size(), b.size()); ++ i) {
    if (a[i] != b[i]) break;
    res++;
  }
  return res;
}

int main() {
  ios::sync_with_stdio(0);cin.tie(0);
  ll n,k;
  cin>>n>>k;
  vector<string> a(n);
  F(n)cin>>a[i];
  ll res=0;
  for (int i = 0; i < n; ++ i) {
    ll cur=0;
    for (int j = i; j < n; ++ j) {
      for (int k = i; k < j; ++ k) {
        cur += cost(a[k], a[j]);
      }
      if (cur >= k) res++;
    }
  }
  out(res);

  return 0;
}
