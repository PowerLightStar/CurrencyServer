import fileinput
# This one shall fail .. if it wont make some data with plenty of different strings with length apx 10 -- but the "K" is slightly tricky here
def D(a):print(a)
def S(s,I):return int(s.split(" ")[I])
MOD=1000000007
PM=31
z=-1
for l in fileinput.input():
    z+=1
    if not z:
        N=S(l,0)
        K=S(l,1)
        s=[0]*N
    s[z-1] = [ ord(i) - 96 for i in l[:-1]]
J = P = T = 0
X = dict()
for i in range(N):
    while P < K:
        if J == N: break
        V = 0
        for v in s[J]:
            V = (V*PM + v)%MOD
            if not V in X:
                X[V] = 0
            P+=X[V]
            X[V]+=1
        J+=1
    if P < K:break
    T += N-J+1
    V=0
    for v in s[i]:
        V = (V*PM + v)%MOD
        X[V]-=1
        P-=X[V]
D(T)
