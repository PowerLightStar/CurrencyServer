#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using ld=double;
using vll=vector<ll>;
using vvll=vector<vector<ll>>;
#define FOR(i,a,b) for(ll i=a;i<(ll)b;++i)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define aa first
#define bb second
#define PB push_back
#define EQ(a,b) (fabs(a-b)<=(fabs(a+b)*EPS))
#define MOD ((ll)(1e9+7))
#define MOD2 ((ll)(1e9+9))
#define MOD3 ((ll)(1e9+21))
#define dbg cerr
#define out(n) cout << n << '\n'
#define PRIME 257

int main(){
  ll n,k;
  cin>>n>>k;
  vector<string> s(n);
  F(n){
    cin>>s[i];
  }
  ll r=0;
  ll val = 0;
  ll res=0;
  map<pair<pair<ll,ll>,ll>,ll> prefixes;

  ll substr=0;
  ll substr2=0;
  ll substr3=0;
  for (int i = 0; i < s[r].size(); ++ i) {
    substr = (substr*PRIME + s[r][i])%MOD;
    substr2 = (substr2*PRIME + s[r][i])%MOD2;
    substr3 = (substr3*PRIME + s[r][i])%MOD3;
    pair<pair<ll,ll>,ll> h = {{substr, substr2}, substr3};
    prefixes[h] ++;
  }

  for (int l=0;l<n;++l) {
    if (l > 0) { // remove the previous one
      ll substr=0;
      ll substr2=0;
      ll substr3=0;
      for (int i = 0; i < s[l-1].size(); ++ i) {
        substr = (substr*PRIME + s[l-1][i])%MOD;
        substr2 = (substr2*PRIME + s[l-1][i])%MOD2;
        substr3 = (substr3*PRIME + s[l-1][i])%MOD3;
        pair<pair<ll,ll>,ll> h = {{substr, substr2}, substr3};
        prefixes[h] --;
        val -= prefixes[h];
      }
    }
    while (val < k && r < n-1) {
      r ++;
      ll substr=0;
      ll substr2=0;
      ll substr3=0;
      for (int i = 0; i < s[r].size(); ++ i) {
        substr = (substr*PRIME + s[r][i])%MOD;
        substr2 = (substr2*PRIME + s[r][i])%MOD2;
        substr3 = (substr3*PRIME + s[r][i])%MOD3;
        pair<pair<ll,ll>,ll> h = {{substr, substr2}, substr3};
        val += prefixes[h];
        prefixes[h] ++;
      }
    }
    if (val >= k) res += n - r;
  }
  out(res);
}
