#include <bits/stdc++.h>
using namespace std;

typedef long long int ll;
typedef pair<int, int> pii;
bool R(){return true;}
template<typename T, typename ... Args>
bool R(T & x, Args & ... args){return cin >> x && R(args...);}
void init_io(){ios::sync_with_stdio(false);cin.tie(0);}

#define PB push_back
#define FOR(prom, a, b) for(int prom = (a); prom < (b); prom++)
#define FORDE(prom, a, b) for(int prom = (a); prom >= (b); prom--)
#define ALL(vec) (vec).begin(), (vec).end()
#define MM(co, cim) memset((co), (cim), sizeof((co)))
#define DEB(x) cerr << ">>> " << #x << " : " << x << endl;
#define INF   1000000007
#define INFLL 4000000000000000007LL

struct status
{
  status (char o, bool is_first, bool is_last)
         : o(o), is_first(is_first), is_last(is_last) 
  {
    this->is_edge = (is_first || is_last);
  }
  
  char o;
  bool is_first;
  bool is_last;
  bool is_edge;
};

int n, m, s, x, y, len, id, u[500014], comp[500014], num_non_ends[1014][1014];
char o;
vector<pair<int, status>> pts[1014][1014];
vector<int> ig[500014], ig_t[500014], order;
vector<pii> clauses;

int get_term (int x)
{
  return 2 * (abs(x) - 1) + (x < 0 ? 1 : 0);
}

void go (int x) 
{
  u[x] = 1;
  for (int y : ig[x]) if (!u[y]) go(y);
  order.PB(x);
}

void go2 (int x, int c) 
{
  comp[x] = c;
  for (int y : ig_t[x]) if (comp[y] == -1) go2(y, c);
}

bool solve_2sat (void)
{
  //construct implication graph + its transpose
  for (auto it : clauses) 
  {
    ig[get_term(it.first)].PB(get_term(it.second));
    ig_t[get_term(it.second)].PB(get_term(it.first));
    ig[get_term(-it.second)].PB(get_term(-it.first));
    ig_t[get_term(-it.first)].PB(get_term(-it.second));
  }
  //get scc's
  MM(u, 0);
  MM(comp, -1);
  FOR(i, 0, 2 * s) if (!u[i]) go(i);
  int j = 0;
  FOR(i, 0, 2 * s)
  {
    int x = order[2 * s - i - 1];
    if (comp[x] == -1) go2(x, j++);
  }
  //check validity
  FOR(i, 0, s) if (comp[2 * i] == comp[2 * i + 1]) return false;
  return true;
}

pii get_next (char o)
{
  switch (o)
  {
    case 'L':
      return {0, -1};
    case 'R':
      return {0, 1};
    case 'U':
      return {-1, 0};
    case 'D':
      return {1, 0};
  }
  return {0, 0};
}

bool is_not_neg (const status & st)
{
  switch (st.o)
  {
    case 'L':
      return st.is_last;
    case 'R':
      return st.is_first;
    case 'U':
      return st.is_last;
    case 'D':
      return st.is_first;
  }
  return false;
}

void add_definitive_clause (int x)
{
  clauses.PB({-x, x});
}

void add_mixup_clauses (int x, int y)
{
  clauses.PB({x, -y});
  clauses.PB({y, -x});
}

void solve ()
{
  R(n, m, s);
  id = 0;
  FOR(qq, 0, s)
  {
    R(x, y, len, o);
    --x;
    --y;
    int cx = x;
    int cy = y;
    ++id;
    //printf("(%d,%d,%d,%c)=%d\n", x, y, len, o, id);
    FOR(i, 0, len)
    {
      pts[cx][cy].PB({id, status(o, !i, i == len - 1)});
      bool is_edge = (!i || (i == len - 1));
      if (!is_edge && ++num_non_ends[cx][cy] >= 2)
      {
        printf("No\n");
        return;
      }
      pii step = get_next(o);
      cx += step.first;
      cy += step.second;
    }
  }
  FOR(i, 0, n) FOR(j, 0, m)
  {
    FOR(k, 0, pts[i][j].size()) FOR(l, k + 1, pts[i][j].size())
    {
      pair<int, status> pl_1 = pts[i][j][k];
      pair<int, status> pl_2 = pts[i][j][l];
      if (!pl_1.second.is_edge && !pl_2.second.is_edge)
      {
        printf("No\n");
        return;
      }
      if (pl_2.second.is_edge) swap(pl_1, pl_2);
      bool non_neg_pl_1 = is_not_neg(pl_1.second);
      bool non_neg_pl_2 = is_not_neg(pl_2.second);
      if (!pl_2.second.is_edge) add_definitive_clause(pl_1.first * (non_neg_pl_1 ? -1 : 1));
      else add_mixup_clauses(pl_1.first * (non_neg_pl_1 ? 1 : -1), pl_2.first * (non_neg_pl_2 ? 1 : -1));
    }
  }
  printf("%s\n", solve_2sat() ? "Yes" : "No");
}

int main ()
{
  init_io();
  int T = 1;
  //R(T);
  while (T--) solve();
  return 0;
}
