#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define ZERO (1e-10)
#define INF int(1e9+1)
#define CL(A,I) (memset(A,I,sizeof(A)))
#define DEB printf("DEB!\n");
#define D(X) cout<<"  "<<#X": "<<X<<endl;
#define EQ(A,B) (A+ZERO>B&&A-ZERO<B)
typedef long long ll;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
#define IN(n) int n;scanf("%d",&n);
#define FOR(i, m, n) for (int i(m); i < n; i++)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define FT(m, n) FOR(k, m, n)
#define aa first
#define bb second
void ga(int N,int *A){F(N)scanf("%d",A+i);}
#define MX 512
#define MV (MX*MX*4)
#define ME (MV*8)
struct HK{
    int C[MV],d[MV],q[MV],E[ME],X[ME],g[MV],n,m,x,f,t;//f==from | t==to
    void giv(int u,int e){X[m]=g[u],g[u]=m,E[m++]=e;}
    void ini(int X){x=X,n=2*x+2,f=0,t=2*x+1,m=0,CL(g,-1);}
    void add(int a,int b){giv(1+a,x+1+b);}
    bool bfs(){
        int b(0),l(0),v,p;
        F(x)if(C[i+1])d[i+1]=INF;
        else d[i+1]=0,q[l++]=i+1;
        *d=INF;
        while(b<l)for(int i(g[v=q[b++]]);~i;i=X[i])
            if(d[p=C[E[i]]]==INF)d[p]=d[v]+1,q[l++]=p;
        return *d!=INF;
    }
    bool dfs(int u){
        if(!u)return 1;
        for(int i(g[u]);~i;i=X[i]){
            int &e(E[i]),p(C[e]);
            if(d[p]==d[u]+1&&dfs(p))return C[e]=u,C[u]=e,1;
        }
        return d[u]=INF,0;
    }
    int mm(){
        int m(0);
        CL(C,0);
        while(bfs())F(x)if(!C[i+1]&&dfs(i+1))++m;
        return m;
    }
}g;
#define GD(A,B) (A*Y+B)
char c;
int X, Y, N, x, y, l, dx, dy,C[MX][MX];
vii z[MX*MX];
bool go(){
    scanf("%d%d%d",&X,&Y,&N);
    g.ini(2*max(X*Y,N));
    F(N){
        scanf("%d%d%d %c", &x, &y, &l, &c),--x,--y, dx=dy=0;
        if(c==68)dx=1;
        if(c==85)dx=-1;
        if(c==82)dy=1;
        if(c==76)dy=-1;
        z[i].PB({x,y});
        F(l-2){
            x+=dx,y+=dy;
            if(C[x][y]++)return 0;
        }
        z[i].PB({x+dx, y+dy});
    }
    F(N){
        for(auto&h:z[i])
            if(!C[h.aa][h.bb])
                g.add(i,GD(h.aa,h.bb));
    }
    return g.mm()==N;
}
int main(void){
    puts(go()?"Yes":"No");
    return 0;
}
